# Walrus Monitor

A self-hosted, read-only monitoring dashboard for the BatteryEVO Walrus G4 inverter and battery system.

Walrus Monitor reads telemetry from the Walrus G4 Wi-Fi datalogger, stores history locally, and provides a browser dashboard, HTTP API, exports, alerts, and solar-savings estimates.

It is designed for users who want local ownership of their monitoring data without adding a control path to the inverter.

> Walrus Monitor is an independent community project and is not affiliated with or endorsed by BatteryEVO.

## What It Does

Walrus Monitor can display and record:

- Battery state of charge and voltage
- Estimated stored battery energy
- Charging, discharging, and idle state
- Solar/PV voltage, current, power, and production
- House/load power
- Grid presence
- Inverter operating mode
- Output voltage and frequency
- System temperature
- Daily energy summaries
- Historical charts
- Alerts and events
- Service diagnostics
- Solar savings and payback estimates

Some values are measured directly from inverter registers. Others are derived or estimated when the inverter does not expose a confirmed direct measurement.

## Read-Only by Design

Walrus Monitor is intentionally a monitoring application.

It uses Modbus function `0x03` holding-register reads and does not include a Modbus write path.

Walrus Monitor does not change battery settings, charge limits, voltage settings, inverter configuration, grid settings, or operating modes.

Dashboard management actions affect only Walrus Monitor's local data.

## How It Works

```text
Walrus G4
    |
Wi-Fi DTU / Datalogger
    |
TCP 18899
    |
Walrus Monitor
    |
    +--> Live system state
    +--> SQLite history
    +--> Web dashboard
    +--> HTTP API
    +--> Alerts / notifications
```

Walrus Monitor accepts the DTU connection on TCP port `18899`, performs read-only polling, normalizes the returned telemetry, and stores timestamped history locally.

## Dashboard

The dashboard provides a single view of solar production, battery status, AC/load information, power flow, energy history, savings/payback, events, alerts, and diagnostics.

Dark and light themes are supported.

## Local History

Walrus Monitor stores telemetry in SQLite. Raw and summarized history have configurable retention periods, and CSV/JSON exports are available through the API.

## Solar Savings & Payback

Walrus Monitor can estimate the value of generated solar energy using timestamped PV production collected locally.

This avoids relying on the inverter's lifetime-production counter, which may be reset.

Supported features include configurable savings start dates, time-of-use periods, editable rates, fuel/rider adjustments, fixed-charge display, optional installed system cost, annualized savings, simple payback, payback progress, and an optional historical baseline.

Historical baseline values are optional and disabled by default.

Utility rates and tariff rules can change. Built-in plans are editable starting points only. Always verify configured values against your current utility tariff or bill.

Walrus Monitor estimates avoided energy cost. It is not a utility billing system.

## Alerts and Notifications

Configurable alerts include low SOC, low/critical battery voltage, high temperature, high load, grid loss/restoration, and telemetry loss/recovery.

Optional notification integrations include MQTT, Gotify, and generic webhooks. They are disabled by default.

## API

```text
/                         Dashboard
/api/status               Current normalized status
/api/history              Recent telemetry history
/api/daily                Daily summaries
/api/events               Event history
/api/diagnostics          Service diagnostics
/api/export/raw.csv       Raw telemetry CSV
/api/export/daily.csv     Daily summary CSV
/api/export/events.csv    Event CSV
/api/export/events.json   Event JSON
/metrics                  Prometheus metrics
```

## Docker Installation

Copy the example configuration:

```sh
cp .env.example .env
```

Review `.env` for your installation, then validate and start:

```sh
docker compose config
docker compose up -d --build
```

By default, TCP `18899` is used for the DTU connection, the dashboard/API is published on host TCP `8790`, persistent data is stored in the `walrus-data` Docker volume, and the dashboard is bound to localhost for safety.

See `.env.example` for available configuration options.

## Device Profile

The default device profile is:

```text
profiles/batteryevo-walrus-g4.yaml
```

## Security

The recommended deployment is local-only.

Do not expose TCP `18899` directly to the Internet.

If remote dashboard access is required, use a trusted VPN or authenticated reverse proxy.

The supplied Docker configuration uses `no-new-privileges`, drops Linux capabilities, uses a read-only root filesystem, and stores persistent data in a Docker volume.

## Data Ownership

Walrus Monitor keeps monitoring history locally. There is no requirement for a hosted monitoring service.

## Project Goals

Walrus Monitor is intended to provide local ownership of telemetry, read-only monitoring, long-term history, transparent calculations, a clean dashboard, exportable data, API access, and easy self-hosting.

## Disclaimer

Walrus Monitor is provided for monitoring and informational purposes.

It is not a battery-management system, inverter controller, safety controller, or replacement for manufacturer documentation.

Verify important readings against the equipment and manufacturer documentation before making operational decisions.
