from __future__ import annotations

import asyncio
import json
import logging
import os
import ssl
from typing import Any

LOG = logging.getLogger("walrus-monitor.mqtt")


def _remaining_length(value: int) -> bytes:
    out = bytearray()
    while True:
        digit = value % 128
        value //= 128
        if value > 0:
            digit |= 0x80
        out.append(digit)
        if value == 0:
            return bytes(out)


def _utf8(value: str) -> bytes:
    data = value.encode("utf-8")
    return len(data).to_bytes(2, "big") + data


class MQTTPublisher:
    """Minimal optional MQTT 3.1.1 QoS-0 publisher using only stdlib.

    It opens a short-lived connection per publish. That is intentionally simple and
    isolated from the battery polling path. Failures never stop monitoring.
    """

    def __init__(self) -> None:
        self.enabled = os.getenv("WALRUS_MQTT_ENABLED", "false").lower() in {"1", "true", "yes", "on"}
        self.host = os.getenv("WALRUS_MQTT_HOST", "")
        self.port = int(os.getenv("WALRUS_MQTT_PORT", "1883"))
        self.topic = os.getenv("WALRUS_MQTT_TOPIC", "walrus/status")
        self.username = os.getenv("WALRUS_MQTT_USERNAME") or None
        self.password = os.getenv("WALRUS_MQTT_PASSWORD") or None
        self.use_tls = os.getenv("WALRUS_MQTT_TLS", "false").lower() in {"1", "true", "yes", "on"}
        self.client_id = os.getenv("WALRUS_MQTT_CLIENT_ID", "walrus-monitor")
        self.timeout = float(os.getenv("WALRUS_MQTT_TIMEOUT", "4"))

    async def publish_status(self, payload: dict[str, Any]) -> None:
        if not self.enabled or not self.host:
            return
        try:
            await asyncio.wait_for(self._publish(payload), timeout=self.timeout)
        except Exception as exc:  # noqa: BLE001
            LOG.warning("MQTT publish failed: %s", exc)

    async def _publish(self, payload: dict[str, Any]) -> None:
        ssl_ctx = ssl.create_default_context() if self.use_tls else None
        reader, writer = await asyncio.open_connection(self.host, self.port, ssl=ssl_ctx)
        try:
            flags = 0x02  # clean session
            variable = _utf8("MQTT") + bytes([4, flags, 0, 30])
            body = _utf8(self.client_id)
            if self.username is not None:
                flags |= 0x80
                body += _utf8(self.username)
                if self.password is not None:
                    flags |= 0x40
                    body += _utf8(self.password)
                variable = _utf8("MQTT") + bytes([4, flags, 0, 30])
            packet = bytes([0x10]) + _remaining_length(len(variable) + len(body)) + variable + body
            writer.write(packet)
            await writer.drain()
            connack = await reader.readexactly(4)
            if connack[0] != 0x20 or connack[3] != 0:
                raise RuntimeError(f"MQTT CONNACK failure: {connack.hex()}")

            message = json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
            publish_body = _utf8(self.topic) + message
            # QoS 0, RETAIN=1 so home-automation consumers immediately get latest state.
            writer.write(bytes([0x31]) + _remaining_length(len(publish_body)) + publish_body)
            writer.write(b"\xe0\x00")  # DISCONNECT
            await writer.drain()
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:  # noqa: BLE001
                pass
