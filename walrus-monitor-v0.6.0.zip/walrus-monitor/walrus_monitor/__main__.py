from __future__ import annotations

import asyncio
import logging
import os

from .mqtt import MQTTPublisher
from .notify import AlertNotifier
from .profile import DeviceProfile
from .server import HTTPServer, WalrusTCPServer
from .state import MonitorState, VERSION
from .storage import Storage
from .tariff import georgia_power_overnight_advantage


def env_float(name: str, default: float) -> float:
    return float(os.getenv(name, str(default)))


def env_int(name: str, default: int) -> int:
    return int(os.getenv(name, str(default)))


def env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def env_optional_float(name: str) -> float | None:
    value = os.getenv(name)
    if value is None or not value.strip():
        return None
    return float(value)


async def amain() -> None:
    logging.basicConfig(
        level=os.getenv("LOG_LEVEL", "INFO").upper(),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )

    poll_interval = env_float("WALRUS_POLL_INTERVAL", 15.0)
    profile = DeviceProfile.load(
        os.getenv("WALRUS_DEVICE_PROFILE", "/app/profiles/batteryevo-walrus-g4.yaml")
    )
    storage = Storage(
        path=os.getenv("WALRUS_DB_PATH", "/data/walrus.db"),
        timezone_name=os.getenv("WALRUS_TIMEZONE", "UTC"),
        raw_retention_days=env_int("WALRUS_RAW_RETENTION_DAYS", 30),
        daily_retention_days=env_int("WALRUS_DAILY_RETENTION_DAYS", 1096),
        max_integration_gap_s=env_float("WALRUS_MAX_INTEGRATION_GAP", 120.0),
        legacy_energy_path=os.getenv("WALRUS_ENERGY_STATE_PATH", "/data/energy.json"),
        backup_dir=os.getenv("WALRUS_DB_BACKUP_DIR", "/data/backups"),
        backup_keep=env_int("WALRUS_DB_BACKUP_KEEP", 5),
        backup_retention_days=env_int("WALRUS_BACKUP_RETENTION_DAYS", 30),
    )
    storage.log_event("info", "service_start", f"walrus-monitor v{VERSION} started", {"profile": profile.id})

    notifier = AlertNotifier()

    rate_plan = None
    if env_bool("WALRUS_SAVINGS_ENABLED", False):
        plan_name = os.getenv(
            "WALRUS_RATE_PLAN",
            "georgia_power_overnight_advantage",
        ).strip().lower()

        if plan_name == "georgia_power_overnight_advantage":
            rate_plan = georgia_power_overnight_advantage(
                savings_start_date=os.getenv(
                    "WALRUS_SAVINGS_START_DATE",
                    "",
                ).strip() or None,
                system_cost=env_optional_float("WALRUS_SOLAR_SYSTEM_COST"),
                super_off_peak_rate=env_float(
                    "WALRUS_RATE_SUPER_OFF_PEAK",
                    0.021859,
                ),
                off_peak_rate=env_float(
                    "WALRUS_RATE_OFF_PEAK",
                    0.101676,
                ),
                on_peak_rate=env_float(
                    "WALRUS_RATE_ON_PEAK",
                    0.297868,
                ),
                off_peak_fuel_rate=env_float(
                    "WALRUS_RATE_FUEL_OFF_PEAK",
                    0.037441,
                ),
                on_peak_fuel_rate=env_float(
                    "WALRUS_RATE_FUEL_ON_PEAK",
                    0.052269,
                ),
                fixed_daily_charge=env_float(
                    "WALRUS_RATE_FIXED_DAILY",
                    0.4603,
                ),
            )
        else:
            raise ValueError(
                f"Unsupported WALRUS_RATE_PLAN={plan_name!r}. "
                "Supported: georgia_power_overnight_advantage"
            )

    state = MonitorState(
        profile=profile,
        storage=storage,
        poll_interval_s=poll_interval,
        capacity_kwh=env_float("WALRUS_CAPACITY_KWH", 23.0),
        inverter_efficiency=env_float("WALRUS_INVERTER_EFFICIENCY", 0.95),
        inverter_idle_w=env_float("WALRUS_INVERTER_IDLE_W", 0.0),
        charger_efficiency=env_float("WALRUS_CHARGER_EFFICIENCY", 0.95),
        ac_charge_amps=env_float("WALRUS_AC_CHARGE_AMPS", 0.0),
        cc_v=env_float("WALRUS_CC_V", 99.6),
        fla_v=env_float("WALRUS_FLA_V", 97.3),
        dc_recr_v=env_float("WALRUS_DC_RECR_V", 88.0),
        lv_off_v=env_float("WALRUS_LV_OFF_V", 72.0),
        lv_alm_v=env_float("WALRUS_LV_ALM_V", 80.0),
        ac_kcin_v=env_float("WALRUS_AC_KCIN_V", 80.0),
        pv_total_base_kwh=env_float("WALRUS_PV_TOTAL_BASE_KWH", 0.0),
        soc_low_alert_pct=env_float("WALRUS_ALERT_SOC_LOW_PCT", 20.0),
        voltage_low_alert_v=env_float("WALRUS_ALERT_VOLTAGE_LOW_V", 80.0),
        voltage_critical_alert_v=env_float("WALRUS_ALERT_VOLTAGE_CRITICAL_V", 72.0),
        temperature_high_alert_f=env_float("WALRUS_ALERT_TEMP_HIGH_F", 115.0),
        load_high_alert_pct=env_float("WALRUS_ALERT_LOAD_HIGH_PCT", 90.0),
        alert_voltage_hysteresis_v=env_float("WALRUS_ALERT_VOLTAGE_HYSTERESIS_V", 1.0),
        alert_soc_hysteresis_pct=env_float("WALRUS_ALERT_SOC_HYSTERESIS_PCT", 5.0),
        alert_temperature_hysteresis_f=env_float("WALRUS_ALERT_TEMP_HYSTERESIS_F", 5.0),
        alert_cooldown_s=env_float("WALRUS_ALERT_COOLDOWN_SECONDS", 900.0),
        grid_loss_alert_enabled=env_bool("WALRUS_ALERT_GRID_LOSS", False),
        stale_after_s=env_float("WALRUS_STALE_AFTER", 90.0),
        grid_present_threshold_v=env_float("WALRUS_GRID_PRESENT_THRESHOLD_V", 50.0),
        solar_active_threshold_w=env_float("WALRUS_SOLAR_ACTIVE_THRESHOLD_W", 20.0),
        battery_idle_threshold_w=env_float("WALRUS_BATTERY_IDLE_THRESHOLD_W", 50.0),
        nominal_output_frequency_hz=env_optional_float("WALRUS_NOMINAL_OUTPUT_FREQUENCY_HZ"),
        notifier=notifier,
        rate_plan=rate_plan,
        historical_pv_kwh=env_float("WALRUS_HISTORICAL_PV_KWH", 0.0),
        historical_savings=env_float("WALRUS_HISTORICAL_SAVINGS", 0.0),
        historical_label=os.getenv("WALRUS_HISTORICAL_LABEL", "").strip() or None,
    )

    mqtt = MQTTPublisher()
    tcp = WalrusTCPServer(state, mqtt=mqtt)
    http = HTTPServer(state)
    tcp_server, http_server = await asyncio.gather(tcp.start(), http.start())

    try:
        async with tcp_server, http_server:
            await asyncio.gather(tcp_server.serve_forever(), http_server.serve_forever())
    finally:
        storage.log_event("info", "service_stop", f"walrus-monitor v{VERSION} stopped")
        storage.close()


def main() -> None:
    try:
        asyncio.run(amain())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
