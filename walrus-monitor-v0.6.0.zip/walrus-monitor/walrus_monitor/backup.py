"""Create a consistent manual SQLite backup without changing the database schema."""

from __future__ import annotations

from datetime import datetime, timezone
import os
from pathlib import Path
import sqlite3


def main() -> None:
    source_path = Path(os.getenv("WALRUS_DB_PATH", "/data/walrus.db"))
    backup_dir = Path(os.getenv("WALRUS_DB_BACKUP_DIR", "/data/backups"))
    keep = max(1, int(os.getenv("WALRUS_DB_BACKUP_KEEP", "5")))

    if not source_path.exists():
        raise SystemExit(f"database not found: {source_path}")

    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    destination = backup_dir / f"walrus-manual-{stamp}.db"

    source = sqlite3.connect(f"file:{source_path}?mode=ro", uri=True)
    target = sqlite3.connect(destination)
    try:
        source.backup(target)
        target.commit()
    finally:
        target.close()
        source.close()

    backups = sorted(backup_dir.glob("walrus-manual-*.db"), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in backups[keep:]:
        old.unlink(missing_ok=True)

    print(destination)


if __name__ == "__main__":
    main()
