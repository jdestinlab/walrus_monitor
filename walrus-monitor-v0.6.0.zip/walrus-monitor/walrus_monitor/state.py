from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

from .profile import DeviceProfile
from .storage import Storage
from .tariff import RatePlan


VERSION = "0.6.0"


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _age_seconds(value: str | None) -> float | None:
    if not value:
        return None
    try:
        then = datetime.fromisoformat(value)
        if then.tzinfo is None:
            then = then.replace(tzinfo=timezone.utc)
        return max(0.0, (datetime.now(timezone.utc) - then).total_seconds())
    except Exception:
        return None


@dataclass
class MonitorState:
    profile: DeviceProfile
    storage: Storage
    poll_interval_s: float = 15.0
    capacity_kwh: float = 23.0
    inverter_efficiency: float = 0.95
    inverter_idle_w: float = 0.0
    charger_efficiency: float = 0.95
    ac_charge_amps: float = 0.0
    cc_v: float = 99.6
    fla_v: float = 97.3
    dc_recr_v: float = 88.0
    lv_off_v: float = 72.0
    lv_alm_v: float = 80.0
    ac_kcin_v: float = 80.0
    pv_total_base_kwh: float = 0.0
    soc_low_alert_pct: float = 20.0
    voltage_low_alert_v: float = 80.0
    voltage_critical_alert_v: float = 72.0
    temperature_high_alert_f: float = 115.0
    load_high_alert_pct: float = 90.0
    alert_voltage_hysteresis_v: float = 1.0
    alert_soc_hysteresis_pct: float = 5.0
    alert_temperature_hysteresis_f: float = 5.0
    alert_cooldown_s: float = 900.0
    grid_loss_alert_enabled: bool = False
    stale_after_s: float = 90.0
    grid_present_threshold_v: float = 50.0
    solar_active_threshold_w: float = 20.0
    battery_idle_threshold_w: float = 50.0
    nominal_output_frequency_hz: float | None = None
    notifier: Any | None = None
    rate_plan: RatePlan | None = None
    historical_pv_kwh: float = 0.0
    historical_savings: float = 0.0
    historical_label: str | None = None

    connected: bool = False
    peer: str | None = None
    connected_at: str | None = None
    last_seen: str | None = None
    last_poll: str | None = None
    last_heartbeat: str | None = None
    last_error: str | None = None
    poll_count: int = 0
    crc_errors: int = 0
    timeouts: int = 0
    reconnects: int = 0
    registers: dict[int, int] = field(default_factory=dict)
    _alert_active: dict[str, bool] = field(default_factory=dict, repr=False)

    def set_connected(self, peer: str) -> None:
        self.connected = True
        self.peer = peer
        self.connected_at = utc_now_iso()
        self.last_seen = self.connected_at
        self.last_error = None
        self.reconnects += 1
        self.storage.log_event("info", "dtu_connected", f"Walrus DTU connected from {peer}")

    def set_disconnected(self) -> None:
        if self.connected:
            self.storage.log_event(
                "warning",
                "dtu_disconnected",
                "Walrus DTU disconnected",
            )
        self.connected = False
        self._alert_transition(
            "telemetry_unavailable",
            True,
            "Walrus telemetry is unavailable",
            {
                "connected": False,
                "telemetry_age_s": self.telemetry_age_s(),
            },
            severity="warning",
        )

    def touch(self) -> None:
        self.last_seen = utc_now_iso()

    def telemetry_age_s(self) -> float | None:
        return _age_seconds(self.last_poll or self.last_seen)

    def telemetry_stale(self) -> bool:
        age = self.telemetry_age_s()
        return age is None or age > self.stale_after_s

    def healthy(self) -> bool:
        return self.connected and not self.telemetry_stale()

    def record_timeout(self) -> None:
        self.timeouts += 1
        self.last_error = "timeout waiting for Modbus response"
        if self.timeouts == 1 or self.timeouts % 5 == 0:
            self.storage.log_event(
                "warning",
                "modbus_timeout",
                f"Timed out waiting for Walrus response (count={self.timeouts})",
            )
        if self.telemetry_stale():
            self._alert_transition(
                "telemetry_unavailable",
                True,
                "Walrus telemetry is stale or unavailable",
                {
                    "connected": self.connected,
                    "telemetry_age_s": self.telemetry_age_s(),
                    "stale_after_s": self.stale_after_s,
                },
                severity="warning",
            )

    def record_crc_error(self, message: str) -> None:
        self.crc_errors += 1
        self.last_error = message
        self.storage.log_event("warning", "crc_error", message, {"count": self.crc_errors})

    def update_register_block(self, start: int, values: tuple[int, ...]) -> bool:
        for offset, value in enumerate(values):
            self.registers[start + offset] = value
        self.last_poll = utc_now_iso()
        self.last_seen = self.last_poll
        self.poll_count += 1

        complete = bool(self.profile.poll_blocks and start == self.profile.poll_blocks[-1].start)
        if complete:
            sample = self.sample_values()
            self.storage.record_sample(sample)
            self._check_alerts(sample)
            self._alert_transition(
                "telemetry_unavailable",
                False,
                "Walrus telemetry is stale or unavailable",
                {
                    "connected": self.connected,
                    "telemetry_age_s": self.telemetry_age_s(),
                    "stale_after_s": self.stale_after_s,
                },
                severity="warning",
            )
        return complete

    def _read(self, name: str) -> float | int | None:
        return self.profile.read(self.registers, name)

    def sample_values(self) -> dict[str, Any]:
        battery_soc = self._read("battery_soc_pct")
        battery_voltage = self._read("battery_voltage_v")
        temperature_c = self._read("temperature_c")
        load_pct = self._read("load_pct")
        load_power_w = self._read("direct_output_power_w")
        if load_power_w is None:
            load_power_w = self._read("load_power_w")
        if (
            load_power_w is None
            and load_pct is not None
            and self.profile.rated_output_power_w is not None
        ):
            load_power_w = round(
                float(load_pct) * float(self.profile.rated_output_power_w) / 100.0, 3
            )

        actual_frequency = self._read("output_frequency_hz")
        frequency_display_hz = (
            actual_frequency
            if actual_frequency is not None
            else (
                self.nominal_output_frequency_hz
                if self.nominal_output_frequency_hz is not None
                else self.profile.nominal_output_frequency_hz
            )
        )
        mode_raw = self.profile.read_raw(self.registers, "operating_mode")
        mode = self.profile.read_label(self.registers, "operating_mode")
        grid_voltage = self._read("grid_voltage_v")
        pv_power = self._read("pv_power_w")

        # Prefer direct battery telemetry if a future device profile maps it.
        # Otherwise estimate battery flow only in the operating state we can
        # constrain safely: Grid absent + Inverter mode.
        battery_current = self._read("battery_current_a")
        battery_power = self._read("battery_power_w")
        battery_power_source = "telemetry" if battery_power is not None else None
        battery_current_source = "telemetry" if battery_current is not None else None

        grid_present = (
            float(grid_voltage) >= self.grid_present_threshold_v
            if grid_voltage is not None
            else None
        )

        # Controlled testing confirmed bit 0x0004 in raw register 0x0003
        # tracks the onboard AC charger enable state.
        status_flags_raw = self.registers.get(0x0003)
        ac_charger_active = bool(
            status_flags_raw is not None
            and (int(status_flags_raw) & 0x0004)
            and grid_present is True
        )
        ac_charger_input_w = None
        if (
            ac_charger_active
            and grid_voltage is not None
            and float(self.ac_charge_amps) > 0
        ):
            # AC-side estimate from configured charger-current setpoint.
            # This is not measured instantaneous charger current and may
            # overstate actual draw when the charger tapers or limits itself.
            ac_charger_input_w = round(
                float(grid_voltage) * float(self.ac_charge_amps),
                3,
            )

        if (
            battery_power is None
            and ac_charger_active
            and ac_charger_input_w is not None
            and battery_voltage is not None
            and float(battery_voltage) > 0
        ):
            # Estimate battery-side charging from the configured AC charger
            # setpoint. This is modeled rather than measured and may overstate
            # actual charging when the charger tapers or limits itself.
            charger_efficiency = min(
                1.0,
                max(0.50, float(self.charger_efficiency)),
            )
            estimated_battery_charge_w = (
                float(ac_charger_input_w) * charger_efficiency
            )

            # Battery power sign convention:
            #   positive = discharge
            #   negative = charge
            battery_power = round(-estimated_battery_charge_w, 3)
            battery_power_source = "estimated_grid_charger_setpoint"

            if battery_current is None:
                battery_current = round(
                    float(battery_power) / float(battery_voltage),
                    3,
                )
                battery_current_source = "estimated_grid_charger_setpoint"

        if (
            battery_power is None
            and mode == "Inverter"
            and grid_present is False
            and load_power_w is not None
            and battery_voltage is not None
            and float(battery_voltage) > 0
        ):
            efficiency = min(1.0, max(0.50, float(self.inverter_efficiency)))
            required_dc_w = (
                float(load_power_w) / efficiency
                + max(0.0, float(self.inverter_idle_w))
            )
            available_pv_w = max(0.0, float(pv_power or 0.0))

            # Sign convention:
            #   positive = battery discharging
            #   negative = battery charging
            battery_power = round(required_dc_w - available_pv_w, 3)
            battery_current = round(
                float(battery_power) / float(battery_voltage),
                3,
            )
            battery_power_source = "estimated_inverter_balance"
            battery_current_source = "estimated_inverter_balance"

        # Prefer direct Grid telemetry if a future device profile maps it.
        # Otherwise estimate Grid import from the confirmed house/load power
        # whenever Grid input voltage is present. When Grid is absent, the
        # estimated Grid contribution to the house is zero.
        grid_power = self._read("grid_power_w")
        grid_power_source = "telemetry" if grid_power is not None else None
        if grid_power is None and load_power_w is not None and grid_present is not None:
            if grid_present:
                efficiency = min(1.0, max(0.50, float(self.inverter_efficiency)))
                grid_house_w = (
                    float(load_power_w) / efficiency
                    + max(0.0, float(self.inverter_idle_w))
                )
                grid_power = round(
                    grid_house_w + float(ac_charger_input_w or 0.0),
                    3,
                )
                grid_power_source = (
                    "estimated_grid_house_plus_ac_charger_setpoint"
                    if ac_charger_input_w is not None
                    else "estimated_grid_present_load_with_losses"
                )
            else:
                grid_power = 0.0
                grid_power_source = "estimated_grid_present_load_with_losses"

        return {
            "pv_voltage_v": self._read("pv_voltage_v"),
            "pv_current_a": self._read("pv_current_a"),
            "pv_power_w": self._read("pv_power_w"),
            "pv_lifetime_kwh": self._read("pv_lifetime_kwh"),
            "battery_voltage_v": battery_voltage,
            "battery_soc_pct": battery_soc,
            "estimated_stored_kwh": (
                round(self.capacity_kwh * float(battery_soc) / 100.0, 3)
                if battery_soc is not None else None
            ),
            "battery_current_a": battery_current,
            "battery_current_source": battery_current_source,
            "battery_power_w": battery_power,
            "battery_power_source": battery_power_source,
            "grid_voltage_v": grid_voltage,
            "grid_power_w": grid_power,
            "grid_power_source": grid_power_source,
            "ac_charger_active": ac_charger_active,
            "ac_charger_input_w": ac_charger_input_w,
            "output_voltage_v": self._read("output_voltage_v"),
            # Store only actual telemetry in history. A nominal/configured fallback is
            # exposed separately for display so it can never be mistaken for a measured value.
            "output_frequency_hz": actual_frequency,
            "output_frequency_display_hz": frequency_display_hz,
            "output_frequency_source": (
                "telemetry" if actual_frequency is not None else (
                    "profile_nominal" if frequency_display_hz is not None else None
                )
            ),
            "load_pct": load_pct,
            "load_power_w": load_power_w,
            "temperature_c": temperature_c,
            "temperature_f": (
                round((float(temperature_c) * 9.0 / 5.0) + 32.0, 1)
                if temperature_c is not None else None
            ),
            "operating_mode": mode,
            "operating_mode_raw": mode_raw,
        }

    def _check_alerts(self, sample: dict[str, Any]) -> None:
        soc = sample.get("battery_soc_pct")
        battery_v = sample.get("battery_voltage_v")
        temp_f = sample.get("temperature_f")
        load_pct = sample.get("load_pct")
        grid_v = sample.get("grid_voltage_v")

        low_soc_active = False
        if soc is not None:
            clear_at = self.soc_low_alert_pct + self.alert_soc_hysteresis_pct
            low_soc_active = (
                float(soc) < clear_at
                if self._alert_active.get("low_soc", False)
                else float(soc) < self.soc_low_alert_pct
            )
        self._alert_transition(
            "low_soc",
            low_soc_active,
            f"Battery SOC below {self.soc_low_alert_pct:g}%",
            {"soc_pct": soc, "threshold_pct": self.soc_low_alert_pct},
        )

        low_v_active = False
        critical_v_active = False
        if battery_v is not None:
            low_clear = self.voltage_low_alert_v + self.alert_voltage_hysteresis_v
            critical_clear = self.voltage_critical_alert_v + self.alert_voltage_hysteresis_v
            low_v_active = (
                float(battery_v) < low_clear
                if self._alert_active.get("low_battery_voltage", False)
                else float(battery_v) <= self.voltage_low_alert_v
            )
            critical_v_active = (
                float(battery_v) < critical_clear
                if self._alert_active.get("critical_battery_voltage", False)
                else float(battery_v) <= self.voltage_critical_alert_v
            )

        self._alert_transition(
            "low_battery_voltage",
            low_v_active,
            f"Battery voltage at or below {self.voltage_low_alert_v:g} V",
            {"battery_voltage_v": battery_v, "threshold_v": self.voltage_low_alert_v},
            severity="warning",
        )
        self._alert_transition(
            "critical_battery_voltage",
            critical_v_active,
            f"Battery voltage at or below critical threshold {self.voltage_critical_alert_v:g} V",
            {"battery_voltage_v": battery_v, "threshold_v": self.voltage_critical_alert_v},
            severity="alert",
        )

        high_temp_active = False
        if temp_f is not None:
            clear_below = self.temperature_high_alert_f - self.alert_temperature_hysteresis_f
            high_temp_active = (
                float(temp_f) > clear_below
                if self._alert_active.get("high_temperature", False)
                else float(temp_f) > self.temperature_high_alert_f
            )
        self._alert_transition(
            "high_temperature",
            high_temp_active,
            f"Walrus temperature above {self.temperature_high_alert_f:g} F",
            {"temperature_f": temp_f, "threshold_f": self.temperature_high_alert_f},
        )

        self._alert_transition(
            "high_load",
            load_pct is not None and float(load_pct) >= self.load_high_alert_pct,
            f"Walrus load at or above {self.load_high_alert_pct:g}%",
            {"load_pct": load_pct, "threshold_pct": self.load_high_alert_pct},
            severity="warning",
        )

        if self.grid_loss_alert_enabled:
            self._alert_transition(
                "grid_loss",
                grid_v is not None and float(grid_v) < self.grid_present_threshold_v,
                "Grid input is unavailable",
                {"grid_voltage_v": grid_v, "threshold_v": self.grid_present_threshold_v},
                severity="alert",
            )

    def _alert_transition(
        self,
        code: str,
        active: bool,
        message: str,
        details: dict[str, Any],
        severity: str = "alert",
    ) -> None:
        was_active = self._alert_active.get(code, False)
        if active and not was_active:
            self.storage.log_event(severity, code, message, details)
            if self.notifier is not None:
                self.notifier.notify(
                    code=code,
                    severity=severity,
                    message=message,
                    details=details,
                    cleared=False,
                )
        elif not active and was_active:
            cleared_message = f"Cleared: {message}"
            self.storage.log_event(
                "info",
                f"{code}_cleared",
                cleared_message,
                details,
            )
            if self.notifier is not None:
                self.notifier.notify(
                    code=code,
                    severity="info",
                    message=cleared_message,
                    details=details,
                    cleared=True,
                )
        self._alert_active[code] = active

    def interpreted(self) -> dict[str, Any]:
        s = self.sample_values()
        pv_generated = self.storage.pv_generated_since_baseline_kwh()

        mapped_lifetime = s.get("pv_lifetime_kwh")
        if mapped_lifetime is not None:
            total_production = float(mapped_lifetime)
            total_source = "device_register"
            total_note = "Lifetime PV production reported directly by the device profile."
        else:
            total_production = self.pv_total_base_kwh + pv_generated
            total_source = "seed_plus_local_integration"
            total_note = "Seeded from an optional device-display baseline, then integrated locally from measured PV power."

        pv: dict[str, Any] = {
            "total_baseline_kwh": round(self.pv_total_base_kwh, 3),
            "generated_since_baseline_kwh": round(pv_generated, 3),
            "total_production_kwh": round(total_production, 3),
            "total_source": total_source,
            "total_note": total_note,
        }
        for key in ("pv_voltage_v", "pv_current_a", "pv_power_w"):
            if s.get(key) is not None:
                pv[key.removeprefix("pv_")] = s[key]
        pv["state"] = "producing" if float(s.get("pv_power_w") or 0) >= self.solar_active_threshold_w else "idle"

        battery: dict[str, Any] = {"capacity_kwh": self.capacity_kwh}
        for src, dst in (
            ("battery_voltage_v", "voltage_v"),
            ("battery_soc_pct", "soc_pct"),
            ("estimated_stored_kwh", "estimated_stored_kwh"),
            ("battery_current_a", "current_a"),
            ("battery_power_w", "power_w"),
        ):
            if s.get(src) is not None:
                battery[dst] = s[src]
        if s.get("battery_current_source") is not None:
            battery["current_source"] = s["battery_current_source"]
        if s.get("battery_power_source") is not None:
            battery["power_source"] = s["battery_power_source"]
        if battery.get("power_source") == "estimated_inverter_balance":
            battery["estimated"] = True
            battery["estimate_assumptions"] = {
                "inverter_efficiency": round(float(self.inverter_efficiency), 4),
                "inverter_idle_w": round(float(self.inverter_idle_w), 3),
                "method": "load/efficiency + idle - measured PV",
            }
        elif battery.get("power_source") == "estimated_grid_charger_setpoint":
            battery["estimated"] = True
            battery["estimate_assumptions"] = {
                "ac_charge_amps_setpoint": round(float(self.ac_charge_amps), 3),
                "grid_voltage_v": s.get("grid_voltage_v"),
                "charger_efficiency": round(float(self.charger_efficiency), 4),
                "method": "grid voltage * AC charger setpoint * charger efficiency",
            }

        battery_power = s.get("battery_power_w")
        grid_present_now = (
            s.get("grid_voltage_v") is not None
            and float(s["grid_voltage_v"]) >= self.grid_present_threshold_v
        )
        charger_active_now = bool(s.get("ac_charger_active"))
        solar_active_now = float(s.get("pv_power_w") or 0.0) >= self.solar_active_threshold_w

        if charger_active_now:
            battery["state"] = "charging"
            battery["charge_source"] = "grid"
            battery["ac_charge_amps_setpoint"] = round(float(self.ac_charge_amps), 3)
            if s.get("ac_charger_input_w") is not None:
                battery["ac_charger_input_w"] = s["ac_charger_input_w"]
        elif battery_power is None and grid_present_now:
            battery["state"] = "idle"
        elif battery_power is None:
            battery["state"] = "unmapped"
        elif float(battery_power) > self.battery_idle_threshold_w:
            battery["state"] = "discharging"
        elif float(battery_power) < -self.battery_idle_threshold_w:
            battery["state"] = "charging"
            if solar_active_now:
                battery["charge_source"] = "solar"
        else:
            battery["state"] = "idle"

        eta_window_minutes = 10
        eta_min_power_w = 100.0
        eta_min_samples = 3
        eta: dict[str, Any] = {
            "available": False,
            "window_minutes": eta_window_minutes,
            "min_power_w": eta_min_power_w,
            "min_samples": eta_min_samples,
        }

        battery_state = battery["state"]
        battery_soc_value = s.get("battery_soc_pct")

        if battery_state in {"discharging", "charging"} and battery_soc_value is not None:
            rolling = self.storage.battery_power_average(
                minutes=eta_window_minutes,
                direction=battery_state,
                min_power_w=eta_min_power_w,
            )
            eta["state"] = battery_state
            eta["average_power_w"] = rolling["average_power_w"]
            eta["sample_count"] = rolling["sample_count"]

            soc = min(100.0, max(0.0, float(battery_soc_value)))
            if battery_state == "discharging":
                target_soc = min(100.0, max(0.0, float(self.soc_low_alert_pct)))
                energy_to_target_kwh = (
                    self.capacity_kwh * max(0.0, soc - target_soc) / 100.0
                )
            else:
                target_soc = 100.0
                energy_to_target_kwh = (
                    self.capacity_kwh * max(0.0, target_soc - soc) / 100.0
                )

            eta["target_soc_pct"] = round(target_soc, 1)
            eta["energy_to_target_kwh"] = round(energy_to_target_kwh, 3)

            if (
                rolling["sample_count"] >= eta_min_samples
                and rolling["average_power_w"] is not None
                and not (
                    battery_state == "charging"
                    and battery.get("charge_source") == "grid"
                )
            ):
                average_power_kw = abs(float(rolling["average_power_w"])) / 1000.0
                eta["hours"] = round(
                    energy_to_target_kwh / average_power_kw,
                    3,
                ) if average_power_kw > 0 else None
                eta["available"] = eta["hours"] is not None
                eta["method"] = "same-direction rolling average battery power"
            else:
                trend = self.storage.battery_soc_trend(minutes=30)
                rate = trend.get("soc_pct_per_hour")

                eta["soc_trend_window_minutes"] = trend["window_minutes"]
                eta["soc_trend_sample_count"] = trend["sample_count"]
                eta["soc_trend_span_minutes"] = trend.get("span_minutes")
                eta["soc_change_pct"] = trend.get("soc_change_pct")
                eta["soc_pct_per_hour"] = rate

                direction_matches = (
                    rate is not None
                    and (
                        (battery_state == "charging" and float(rate) > 0)
                        or (battery_state == "discharging" and float(rate) < 0)
                    )
                )

                if direction_matches:
                    remaining_pct = (
                        max(0.0, target_soc - soc)
                        if battery_state == "charging"
                        else max(0.0, soc - target_soc)
                    )
                    eta["hours"] = round(
                        remaining_pct / abs(float(rate)),
                        3,
                    ) if abs(float(rate)) > 0 else None
                    eta["available"] = eta["hours"] is not None
                    eta["method"] = "observed SOC trend"
                else:
                    eta["reason"] = trend.get(
                        "reason",
                        "soc_trend_direction_mismatch",
                    )
        elif battery_state == "idle":
            eta["state"] = "idle"
            eta["reason"] = "battery_power_below_eta_threshold"
        else:
            eta["state"] = battery_state
            eta["reason"] = "battery_power_unavailable"

        battery["eta"] = eta

        grid: dict[str, Any] = {}
        if s.get("grid_voltage_v") is not None:
            grid["voltage_v"] = s["grid_voltage_v"]
            grid["present"] = float(s["grid_voltage_v"]) >= self.grid_present_threshold_v

        grid["charger_active"] = bool(s.get("ac_charger_active"))
        if s.get("ac_charger_input_w") is not None:
            grid["charger_input_w"] = s["ac_charger_input_w"]
            grid["charger_input_estimated"] = True

        if (
            grid.get("present") is True
            and s.get("load_power_w") is not None
        ):
            efficiency = min(1.0, max(0.50, float(self.inverter_efficiency)))
            grid["house_input_w"] = round(
                float(s["load_power_w"]) / efficiency
                + max(0.0, float(self.inverter_idle_w)),
                3,
            )
            grid["house_input_estimated"] = True
        if s.get("grid_power_w") is not None:
            grid["power_w"] = s["grid_power_w"]
            grid["total_input_w"] = s["grid_power_w"]
            source = s.get("grid_power_source")
            grid["power_source"] = source
            grid["estimated"] = bool(source and str(source).startswith("estimated_"))
            if source == "telemetry":
                grid["direction"] = "import" if float(s["grid_power_w"]) >= 0 else "export"
            elif grid["estimated"]:
                grid["direction"] = "import" if float(s["grid_power_w"]) > 0 else "idle"
                grid["estimate_assumptions"] = {
                    "inverter_efficiency": round(float(self.inverter_efficiency), 4),
                    "inverter_idle_w": round(float(self.inverter_idle_w), 3),
                    "method": "house load / efficiency + idle when Grid is present",
                }

        output: dict[str, Any] = {}
        if s.get("output_voltage_v") is not None:
            output["voltage_v"] = s["output_voltage_v"]
        if s.get("output_frequency_display_hz") is not None:
            output["frequency_hz"] = s["output_frequency_display_hz"]
            output["frequency_source"] = s["output_frequency_source"]
        if s.get("load_pct") is not None:
            output["load_pct"] = s["load_pct"]
        if s.get("load_power_w") is not None:
            output["load_power_w"] = s["load_power_w"]
            output["power_source"] = (
                "direct_register" if self._read("direct_output_power_w") is not None else "load_percent_derived"
            )

        system: dict[str, Any] = {}
        if s.get("temperature_c") is not None:
            system["temperature_c"] = s["temperature_c"]
            system["temperature_f"] = s["temperature_f"]
        if s.get("operating_mode") is not None:
            system["mode"] = s["operating_mode"]
            system["mode_raw"] = s["operating_mode_raw"]

        observed_limits: dict[str, Any] = {}
        for name in ("lv_off_v", "fla_v", "cc_v"):
            value = self._read(name)
            if value is not None:
                observed_limits[name] = value

        flow_complete = all(
            s.get(name) is not None
            for name in ("pv_power_w", "load_power_w", "grid_power_w", "battery_power_w")
        )
        flow = {
            "solar_w": s.get("pv_power_w"),
            "house_w": s.get("load_power_w"),
            "grid_w": s.get("grid_power_w"),
            "battery_w": s.get("battery_power_w"),
            "complete": flow_complete,
            "note": "Power-flow balance becomes complete when both grid and battery power are mapped.",
        }
        if flow_complete:
            # Sign conventions: grid + = import, battery + = discharge, solar/house + = magnitude.
            # This is intentionally called a residual rather than a loss because sensor timing,
            # conversion efficiency, and register quantization can all contribute.
            flow["balance_residual_w"] = round(
                float(s["pv_power_w"])
                + float(s["grid_power_w"])
                + float(s["battery_power_w"])
                - float(s["load_power_w"]),
                3,
            )

        return {
            "pv": pv,
            "battery": battery,
            "grid": grid,
            "output": output,
            "system": system,
            "flow": flow,
            "observed_limits": observed_limits,
        }

    def as_dict(self) -> dict[str, Any]:
        values = self.interpreted()
        age = self.telemetry_age_s()
        stale = self.telemetry_stale()
        return {
            "service": {
                "name": "walrus-monitor",
                "version": VERSION,
                "mode": "local-read-only",
                "connected": self.connected,
                "healthy": self.connected and not stale,
                "telemetry_stale": stale,
                "telemetry_age_s": round(age, 1) if age is not None else None,
                "stale_after_s": self.stale_after_s,
                "peer": self.peer,
                "connected_at": self.connected_at,
                "last_seen": self.last_seen,
                "last_poll": self.last_poll,
                "last_heartbeat": self.last_heartbeat,
                "last_error": self.last_error,
                "poll_count": self.poll_count,
                "crc_errors": self.crc_errors,
                "timeouts": self.timeouts,
                "reconnects": self.reconnects,
                "database_schema": self.storage.schema_version(),
            },
            **values,
            "energy": self.storage.energy_summary(self.poll_interval_s),
            "solar_savings": (
                self.storage.solar_savings_summary(
                    self.rate_plan,
                    historical_pv_kwh=self.historical_pv_kwh,
                    historical_savings=self.historical_savings,
                    historical_label=self.historical_label,
                )
                if self.rate_plan is not None
                else {
                    "enabled": False,
                    "reason": "WALRUS_SAVINGS_ENABLED is false",
                }
            ),
            "limits": {
                "cc_v": self.cc_v,
                "fla_v": self.fla_v,
                "dc_recr_v": self.dc_recr_v,
                "lv_off_v": self.lv_off_v,
                "lv_alm_v": self.lv_alm_v,
                "ac_kcin_v": self.ac_kcin_v,
                "note": "Reference values only; this service cannot write battery settings.",
            },
            "profile": {
                "id": self.profile.id,
                "name": self.profile.name,
                "unmapped": list(self.profile.unmapped),
            },
            "registers": {f"0x{k:04X}": v for k, v in sorted(self.registers.items())},
        }
