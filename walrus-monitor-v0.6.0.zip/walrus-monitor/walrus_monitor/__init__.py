"""walrus-monitor local BatteryEVO monitoring service."""

__version__ = "0.6.0"
