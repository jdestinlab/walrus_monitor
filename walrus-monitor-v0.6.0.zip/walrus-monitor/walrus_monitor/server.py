from __future__ import annotations

import asyncio
import json
import logging
import os
from dataclasses import dataclass
from typing import Any
from urllib.parse import parse_qs, urlsplit

from .dashboard import DASHBOARD_HTML
from .modbus import build_read_holding_registers, expected_response_length, parse_read_holding_response
from .mqtt import MQTTPublisher
from .state import MonitorState, utc_now_iso

LOG = logging.getLogger("walrus-monitor")
HEARTBEAT_QUERY = b"AT+HTBT?\r\n"
HEARTBEAT_REPLY = b"AT+HTBT:\r\n"


@dataclass
class PendingRead:
    start: int
    count: int


class WalrusSession:
    def __init__(
        self,
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
        state: MonitorState,
        mqtt: MQTTPublisher,
        poll_interval: float,
        heartbeat_interval: float,
        response_timeout: float,
        startup_delay: float,
    ) -> None:
        self.reader = reader
        self.writer = writer
        self.state = state
        self.mqtt = mqtt
        self.poll_interval = poll_interval
        self.heartbeat_interval = heartbeat_interval
        self.response_timeout = response_timeout
        self.startup_delay = startup_delay
        self.modbus_responses: asyncio.Queue[bytes] = asyncio.Queue(maxsize=8)
        self.stop = asyncio.Event()
        self.peer = writer.get_extra_info("peername")
        self.pending: PendingRead | None = None

    async def run(self) -> None:
        peer_text = str(self.peer)
        self.state.set_connected(peer_text)
        LOG.info("DTU connected from %s", peer_text)
        tasks = [
            asyncio.create_task(self._reader_loop(), name="dtu-reader"),
            asyncio.create_task(self._poll_loop(), name="dtu-poller"),
            asyncio.create_task(self._heartbeat_loop(), name="dtu-heartbeat"),
        ]
        try:
            done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            for task in done:
                exc = task.exception()
                if exc:
                    raise exc
        except asyncio.CancelledError:
            raise
        except Exception as exc:  # noqa: BLE001
            self.state.last_error = str(exc)
            LOG.warning("DTU session ended: %s", exc)
        finally:
            self.stop.set()
            for task in tasks:
                if not task.done():
                    task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)
            self.state.set_disconnected()
            self.writer.close()
            try:
                await self.writer.wait_closed()
            except Exception:  # noqa: BLE001
                pass
            LOG.info("DTU disconnected: %s", peer_text)

    async def _reader_loop(self) -> None:
        buf = bytearray()
        while not self.stop.is_set():
            chunk = await self.reader.read(4096)
            if not chunk:
                return
            self.state.touch()
            buf.extend(chunk)
            await self._drain_buffer(buf)

    async def _drain_buffer(self, buf: bytearray) -> None:
        while buf:
            if buf.startswith(HEARTBEAT_REPLY):
                del buf[: len(HEARTBEAT_REPLY)]
                self.state.last_heartbeat = utc_now_iso()
                LOG.debug("Heartbeat reply received")
                continue

            if buf.startswith(b"AT+"):
                line_end = buf.find(b"\r\n")
                if line_end == -1:
                    return
                line = bytes(buf[: line_end + 2])
                del buf[: line_end + 2]
                LOG.info("DTU ASCII: %r", line)
                continue

            if len(buf) >= 2 and buf[0] == self.state.profile.slave_id and (buf[1] == 0x03 or (buf[1] & 0x80)):
                frame_len = expected_response_length(bytes(buf))
                if frame_len is None or len(buf) < frame_len:
                    return
                frame = bytes(buf[:frame_len])
                del buf[:frame_len]
                try:
                    parse_read_holding_response(frame)
                except ValueError as exc:
                    if "CRC" in str(exc):
                        self.state.record_crc_error(str(exc))
                    else:
                        self.state.last_error = str(exc)
                    LOG.warning("Dropping invalid Modbus frame %s: %s", frame.hex(), exc)
                    continue
                if self.modbus_responses.full():
                    try:
                        self.modbus_responses.get_nowait()
                    except asyncio.QueueEmpty:
                        pass
                self.modbus_responses.put_nowait(frame)
                continue

            if len(buf) < 3:
                return
            unknown = buf.pop(0)
            LOG.debug("Ignoring unknown DTU byte: 0x%02x", unknown)

    async def _poll_loop(self) -> None:
        await asyncio.sleep(self.startup_delay)
        blocks = self.state.profile.poll_blocks
        if not blocks:
            raise RuntimeError("device profile has no poll blocks")
        while not self.stop.is_set():
            try:
                for index, block in enumerate(blocks):
                    await self._read_block(block.start, block.count)
                    if index != len(blocks) - 1:
                        await asyncio.sleep(0.20)
            except asyncio.TimeoutError:
                self.state.record_timeout()
                LOG.warning("Timed out waiting for Walrus response")
            except Exception as exc:  # noqa: BLE001
                self.state.last_error = str(exc)
                LOG.warning("Poll error: %s", exc)
            await asyncio.sleep(self.poll_interval)

    async def _read_block(self, start: int, count: int) -> None:
        # Safety property: this service only generates Modbus function 0x03 reads.
        request = build_read_holding_registers(self.state.profile.slave_id, start, count)
        self.pending = PendingRead(start=start, count=count)
        LOG.debug("TX read start=0x%04X count=%d frame=%s", start, count, request.hex())
        self.writer.write(request)
        await self.writer.drain()

        frame = await asyncio.wait_for(self.modbus_responses.get(), timeout=self.response_timeout)
        response = parse_read_holding_response(frame)
        if response.slave != self.state.profile.slave_id:
            raise ValueError(f"unexpected slave {response.slave}")
        if len(response.registers) != count:
            raise ValueError(
                f"register count mismatch for 0x{start:04X}: got {len(response.registers)}, expected {count}"
            )
        complete = self.state.update_register_block(start, response.registers)
        self.state.last_error = None
        self.pending = None
        interpreted = self.state.interpreted()
        LOG.info(
            "RX 0x%04X..0x%04X battery=%sV soc=%s%% pv=%sV/%sA/%sW load=%sW",
            start,
            start + count - 1,
            interpreted["battery"].get("voltage_v"),
            interpreted["battery"].get("soc_pct"),
            interpreted["pv"].get("voltage_v"),
            interpreted["pv"].get("current_a"),
            interpreted["pv"].get("power_w"),
            interpreted["output"].get("load_power_w"),
        )
        if complete and self.mqtt.enabled:
            asyncio.create_task(self.mqtt.publish_status(self.state.as_dict()))

    async def _heartbeat_loop(self) -> None:
        await asyncio.sleep(max(2.0, self.startup_delay / 2.0))
        while not self.stop.is_set():
            try:
                self.writer.write(HEARTBEAT_QUERY)
                await self.writer.drain()
            except Exception as exc:  # noqa: BLE001
                self.state.last_error = f"heartbeat send failed: {exc}"
                return
            await asyncio.sleep(self.heartbeat_interval)


class WalrusTCPServer:
    def __init__(self, state: MonitorState, mqtt: MQTTPublisher | None = None) -> None:
        self.state = state
        self.mqtt = mqtt or MQTTPublisher()
        self.host = os.getenv("WALRUS_TCP_HOST", "0.0.0.0")
        self.port = int(os.getenv("WALRUS_TCP_PORT", "18899"))
        self.poll_interval = float(os.getenv("WALRUS_POLL_INTERVAL", "15"))
        self.heartbeat_interval = float(os.getenv("WALRUS_HEARTBEAT_INTERVAL", "35"))
        self.response_timeout = float(os.getenv("WALRUS_RESPONSE_TIMEOUT", "4"))
        self.startup_delay = float(os.getenv("WALRUS_STARTUP_DELAY", "2"))
        self._active_session: asyncio.Task[None] | None = None
        self._server: asyncio.AbstractServer | None = None

    async def start(self) -> asyncio.AbstractServer:
        self._server = await asyncio.start_server(self._accept, self.host, self.port)
        sockets = ", ".join(str(sock.getsockname()) for sock in self._server.sockets or [])
        LOG.info("Walrus TCP server listening on %s", sockets)
        return self._server

    async def _accept(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        if self._active_session and not self._active_session.done():
            LOG.warning("New DTU connection received; replacing previous session")
            self._active_session.cancel()
            await asyncio.gather(self._active_session, return_exceptions=True)

        session = WalrusSession(
            reader=reader,
            writer=writer,
            state=self.state,
            mqtt=self.mqtt,
            poll_interval=self.poll_interval,
            heartbeat_interval=self.heartbeat_interval,
            response_timeout=self.response_timeout,
            startup_delay=self.startup_delay,
        )
        self._active_session = asyncio.create_task(session.run())
        await self._active_session


class HTTPServer:
    """Dependency-free read-only dashboard/API/CSV server."""

    def __init__(self, state: MonitorState) -> None:
        self.state = state
        self.host = os.getenv("WALRUS_HTTP_HOST", "0.0.0.0")
        self.port = int(os.getenv("WALRUS_HTTP_PORT", "8080"))
        self.allow_alert_clear = os.getenv(
            "WALRUS_ALLOW_ALERT_CLEAR", "false"
        ).strip().lower() in {"1", "true", "yes", "on"}
        self.allow_data_reset = os.getenv(
            "WALRUS_ALLOW_DATA_RESET", "false"
        ).strip().lower() in {"1", "true", "yes", "on"}
        self.allow_grid_test = os.getenv(
            "WALRUS_ALLOW_GRID_TEST", "false"
        ).strip().lower() in {"1", "true", "yes", "on"}
        self.allow_grid_reset = os.getenv(
            "WALRUS_ALLOW_GRID_RESET", "false"
        ).strip().lower() in {"1", "true", "yes", "on"}
        self._server: asyncio.AbstractServer | None = None

    async def start(self) -> asyncio.AbstractServer:
        self._server = await asyncio.start_server(self._handle, self.host, self.port)
        sockets = ", ".join(str(sock.getsockname()) for sock in self._server.sockets or [])
        LOG.info("HTTP API listening on %s", sockets)
        return self._server

    @staticmethod
    def _int_arg(query: dict[str, list[str]], name: str, default: int, minimum: int, maximum: int) -> int:
        try:
            return max(minimum, min(maximum, int(query.get(name, [str(default)])[0])))
        except (TypeError, ValueError):
            return default

    async def _handle(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            line = await asyncio.wait_for(reader.readline(), timeout=5)
            if not line:
                return
            parts = line.decode("ascii", "replace").strip().split()
            if len(parts) < 2:
                await self._send(writer, 400, "text/plain; charset=utf-8", b"Bad Request\n")
                return
            method, target = parts[0], parts[1]
            parsed = urlsplit(target)
            path = parsed.path
            query = parse_qs(parsed.query)
            while True:
                h = await asyncio.wait_for(reader.readline(), timeout=5)
                if h in (b"\r\n", b"\n", b""):
                    break

            if method not in {"GET", "POST"}:
                await self._send(
                    writer,
                    405,
                    "text/plain; charset=utf-8",
                    b"Method Not Allowed\n",
                )
                return

            if method == "POST":
                if path == "/api/events/backup":
                    await self._json(
                        writer,
                        {"ok": True, "backup": self.state.storage.backup_events()},
                    )
                elif path == "/api/events/clear":
                    confirm = query.get("confirm", [""])[0]
                    if not self.allow_alert_clear:
                        await self._json(
                            writer,
                            {
                                "ok": False,
                                "error": "Alert clearing is disabled",
                                "enable_with": "WALRUS_ALLOW_ALERT_CLEAR=true",
                            },
                            status=403,
                        )
                    elif confirm != "CLEAR_ALERTS":
                        await self._json(
                            writer,
                            {
                                "ok": False,
                                "error": "Explicit confirmation required",
                                "required_confirm": "CLEAR_ALERTS",
                            },
                            status=400,
                        )
                    else:
                        result = self.state.storage.clear_events(backup_first=True)
                        await self._json(writer, {"ok": True, **result})
                elif path == "/api/grid/test/start":
                    if not self.allow_grid_test:
                        await self._json(
                            writer,
                            {
                                "ok": False,
                                "error": "Grid test sessions are disabled",
                                "enable_with": "WALRUS_ALLOW_GRID_TEST=true",
                            },
                            status=403,
                        )
                    else:
                        label = query.get("label", [""])[0] or None
                        try:
                            session = self.state.storage.start_grid_test_session(
                                float(getattr(self.state, "inverter_efficiency", 0.95)),
                                float(getattr(self.state, "inverter_idle_w", 0.0)),
                                label,
                            )
                        except RuntimeError as exc:
                            await self._json(
                                writer,
                                {"ok": False, "error": str(exc)},
                                status=400,
                            )
                        else:
                            await self._json(writer, {"ok": True, "session": session})
                elif path == "/api/grid/test/stop":
                    if not self.allow_grid_test:
                        await self._json(
                            writer,
                            {
                                "ok": False,
                                "error": "Grid test sessions are disabled",
                                "enable_with": "WALRUS_ALLOW_GRID_TEST=true",
                            },
                            status=403,
                        )
                    else:
                        try:
                            session = self.state.storage.stop_grid_test_session()
                        except RuntimeError as exc:
                            await self._json(
                                writer,
                                {"ok": False, "error": str(exc)},
                                status=400,
                            )
                        else:
                            await self._json(writer, {"ok": True, "session": session})
                elif path == "/api/grid/reset":
                    confirm = query.get("confirm", [""])[0]
                    if not self.allow_grid_reset:
                        await self._json(
                            writer,
                            {
                                "ok": False,
                                "error": "Grid-history reset is disabled",
                                "enable_with": "WALRUS_ALLOW_GRID_RESET=true",
                            },
                            status=403,
                        )
                    elif confirm != "RESET_GRID_HISTORY":
                        await self._json(
                            writer,
                            {
                                "ok": False,
                                "error": "Explicit confirmation required",
                                "required_confirm": "RESET_GRID_HISTORY",
                            },
                            status=400,
                        )
                    else:
                        try:
                            result = self.state.storage.reset_grid_history()
                        except RuntimeError as exc:
                            await self._json(
                                writer,
                                {"ok": False, "error": str(exc)},
                                status=400,
                            )
                        else:
                            await self._json(writer, {"ok": True, **result})
                elif path == "/api/reset":
                    confirm = query.get("confirm", [""])[0]
                    if not self.allow_data_reset:
                        await self._json(
                            writer,
                            {
                                "ok": False,
                                "error": "Monitoring-data reset is disabled",
                                "enable_with": "WALRUS_ALLOW_DATA_RESET=true",
                            },
                            status=403,
                        )
                    elif confirm != "RESET_ALL_DATA":
                        await self._json(
                            writer,
                            {
                                "ok": False,
                                "error": "Explicit confirmation required",
                                "required_confirm": "RESET_ALL_DATA",
                            },
                            status=400,
                        )
                    else:
                        result = self.state.storage.reset_monitoring_data()
                        await self._json(writer, {"ok": True, **result})
                else:
                    await self._send(
                        writer,
                        404,
                        "text/plain; charset=utf-8",
                        b"Not Found\n",
                    )
                return

            if path == "/":
                await self._send(writer, 200, "text/html; charset=utf-8", DASHBOARD_HTML.encode("utf-8"))
            elif path == "/api/status":
                await self._json(writer, self.state.as_dict())
            elif path == "/api/history":
                points = self._int_arg(query, "points", 360, 10, 2000)
                local_date = query.get("date", [""])[0].strip()
                if local_date:
                    rows = self.state.storage.history_for_date(local_date, points)
                    await self._json(
                        writer,
                        {
                            "date": local_date,
                            "raw_retention_days": self.state.storage.raw_retention_days,
                            "points": rows,
                        },
                    )
                else:
                    hours = self._int_arg(
                        query,
                        "hours",
                        24,
                        1,
                        self.state.storage.raw_retention_days * 24,
                    )
                    await self._json(
                        writer,
                        {
                            "hours": hours,
                            "raw_retention_days": self.state.storage.raw_retention_days,
                            "points": self.state.storage.history(hours, points),
                        },
                    )
            elif path == "/api/daily":
                days = self._int_arg(query, "days", 30, 1, 3660)
                await self._json(writer, {"days": days, "rows": self.state.storage.daily(days, self.state.poll_interval_s)})
            elif path == "/api/events":
                limit = self._int_arg(query, "limit", 50, 1, 1000)
                await self._json(writer, {"events": self.state.storage.events(limit)})
            elif path == "/api/grid/test/status":
                await self._json(writer, self.state.storage.grid_test_session_status())
            elif path == "/api/diagnostics":
                await self._json(
                    writer,
                    {
                        "service": self.state.as_dict()["service"],
                        "storage": self.state.storage.diagnostics(),
                        "profile": self.state.profile.as_dict(),
                        "management": {
                            "alert_clear_enabled": self.allow_alert_clear,
                            "data_reset_enabled": self.allow_data_reset,
                            "grid_test_enabled": self.allow_grid_test,
                            "grid_reset_enabled": self.allow_grid_reset,
                        },
                    },
                )
            elif path == "/api/profile":
                await self._json(writer, self.state.profile.as_dict())
            elif path == "/api/export/grid-test.csv":
                session_id = self._int_arg(query, "session", 0, 0, 2147483647)
                if session_id <= 0:
                    await self._json(
                        writer,
                        {"ok": False, "error": "A valid session id is required"},
                        status=400,
                    )
                else:
                    try:
                        body = self.state.storage.grid_test_session_csv(session_id).encode("utf-8")
                    except ValueError as exc:
                        await self._json(writer, {"ok": False, "error": str(exc)}, status=404)
                    else:
                        await self._send(
                            writer,
                            200,
                            "text/csv; charset=utf-8",
                            body,
                            {"Content-Disposition": f'attachment; filename="walrus-grid-test-{session_id}.csv"'},
                        )
            elif path == "/api/export/grid-test.json":
                session_id = self._int_arg(query, "session", 0, 0, 2147483647)
                if session_id <= 0:
                    await self._json(
                        writer,
                        {"ok": False, "error": "A valid session id is required"},
                        status=400,
                    )
                else:
                    try:
                        body = self.state.storage.grid_test_session_json(session_id).encode("utf-8")
                    except ValueError as exc:
                        await self._json(writer, {"ok": False, "error": str(exc)}, status=404)
                    else:
                        await self._send(
                            writer,
                            200,
                            "application/json; charset=utf-8",
                            body,
                            {"Content-Disposition": f'attachment; filename="walrus-grid-test-{session_id}.json"'},
                        )
            elif path == "/api/export/daily.csv":
                days = self._int_arg(query, "days", 30, 1, 3660)
                body = self.state.storage.daily_csv(days, self.state.poll_interval_s).encode("utf-8")
                await self._send(
                    writer,
                    200,
                    "text/csv; charset=utf-8",
                    body,
                    {"Content-Disposition": f'attachment; filename="walrus-daily-{days}d.csv"'},
                )
            elif path == "/api/export/raw.csv":
                days = self._int_arg(query, "days", 1, 1, self.state.storage.raw_retention_days)
                chunks = (chunk.encode("utf-8") for chunk in self.state.storage.raw_csv_chunks(days))
                await self._send_chunked(
                    writer,
                    200,
                    "text/csv; charset=utf-8",
                    chunks,
                    {"Content-Disposition": f'attachment; filename="walrus-raw-{days}d.csv"'},
                )
            elif path == "/api/export/events.csv":
                body = self.state.storage.events_csv().encode("utf-8")
                await self._send(
                    writer,
                    200,
                    "text/csv; charset=utf-8",
                    body,
                    {"Content-Disposition": 'attachment; filename="walrus-events.csv"'},
                )
            elif path == "/api/export/events.json":
                body = self.state.storage.events_json().encode("utf-8")
                await self._send(
                    writer,
                    200,
                    "application/json; charset=utf-8",
                    body,
                    {"Content-Disposition": 'attachment; filename="walrus-events.json"'},
                )
            elif path == "/healthz":
                healthy = self.state.healthy()
                code = 200 if healthy else 503
                await self._json(
                    writer,
                    {
                        "ok": healthy,
                        "connected": self.state.connected,
                        "telemetry_stale": self.state.telemetry_stale(),
                        "telemetry_age_s": self.state.telemetry_age_s(),
                        "last_seen": self.state.last_seen,
                        "last_poll": self.state.last_poll,
                    },
                    status=code,
                )
            elif path == "/metrics":
                await self._send(writer, 200, "text/plain; version=0.0.4", self._metrics().encode())
            else:
                await self._send(writer, 404, "text/plain; charset=utf-8", b"Not Found\n")
        except Exception as exc:  # noqa: BLE001
            LOG.debug("HTTP request error: %s", exc)
        finally:
            writer.close()
            try:
                await writer.wait_closed()
            except Exception:  # noqa: BLE001
                pass

    async def _json(self, writer: asyncio.StreamWriter, payload: Any, status: int = 200) -> None:
        await self._send(
            writer,
            status,
            "application/json",
            json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode("utf-8"),
        )

    async def _send_chunked(
        self,
        writer: asyncio.StreamWriter,
        status: int,
        content_type: str,
        chunks,
        extra_headers: dict[str, str] | None = None,
    ) -> None:
        reason = {
            200: "OK",
            400: "Bad Request",
            403: "Forbidden",
            404: "Not Found",
            405: "Method Not Allowed",
            503: "Service Unavailable",
        }.get(status, "")
        lines = [
            f"HTTP/1.1 {status} {reason}",
            f"Content-Type: {content_type}",
            "Transfer-Encoding: chunked",
            "Cache-Control: no-store",
            "X-Content-Type-Options: nosniff",
            "X-Frame-Options: SAMEORIGIN",
            "Referrer-Policy: no-referrer",
            "Connection: close",
        ]
        for key, value in (extra_headers or {}).items():
            lines.append(f"{key}: {value}")
        writer.write(("\r\n".join(lines) + "\r\n\r\n").encode("ascii"))
        await writer.drain()

        for chunk in chunks:
            if not chunk:
                continue
            writer.write(f"{len(chunk):X}\r\n".encode("ascii"))
            writer.write(chunk)
            writer.write(b"\r\n")
            await writer.drain()
        writer.write(b"0\r\n\r\n")
        await writer.drain()

    async def _send(
        self,
        writer: asyncio.StreamWriter,
        status: int,
        content_type: str,
        body: bytes,
        extra_headers: dict[str, str] | None = None,
    ) -> None:
        reason = {
            200: "OK",
            400: "Bad Request",
            404: "Not Found",
            405: "Method Not Allowed",
            503: "Service Unavailable",
        }.get(status, "")
        lines = [
            f"HTTP/1.1 {status} {reason}",
            f"Content-Type: {content_type}",
            f"Content-Length: {len(body)}",
            "Cache-Control: no-store",
            "X-Content-Type-Options: nosniff",
            "X-Frame-Options: SAMEORIGIN",
            "Referrer-Policy: no-referrer",
            "Connection: close",
        ]
        for key, value in (extra_headers or {}).items():
            lines.append(f"{key}: {value}")
        writer.write(("\r\n".join(lines) + "\r\n\r\n").encode("ascii") + body)
        await writer.drain()

    def _metrics(self) -> str:
        d = self.state.as_dict()
        today = d.get("energy", {}).get("today", {})
        last30 = d.get("energy", {}).get("last_30_days", {})
        lines = [
            "# HELP walrus_connected Whether the BatteryEVO DTU is connected (1/0).",
            "# TYPE walrus_connected gauge",
            f"walrus_connected {1 if self.state.connected else 0}",
        ]
        mapping: list[tuple[str, str, Any]] = [
            ("walrus_battery_voltage_volts", "Battery pack voltage.", d["battery"].get("voltage_v")),
            ("walrus_battery_soc_percent", "Battery state of charge.", d["battery"].get("soc_pct")),
            ("walrus_battery_estimated_stored_kwh", "Estimated stored energy.", d["battery"].get("estimated_stored_kwh")),
            ("walrus_pv_voltage_volts", "PV voltage.", d["pv"].get("voltage_v")),
            ("walrus_pv_current_amps", "PV current.", d["pv"].get("current_a")),
            ("walrus_pv_power_watts", "PV power.", d["pv"].get("power_w")),
            ("walrus_pv_total_production_kwh", "Seeded lifetime PV production plus local integration.", d["pv"].get("total_production_kwh")),
            ("walrus_pv_today_kwh", "Locally integrated PV energy today.", today.get("pv_generated_kwh")),
            ("walrus_pv_last_30_days_kwh", "Locally integrated PV energy over the last 30 days.", last30.get("pv_generated_kwh")),
            ("walrus_grid_voltage_volts", "AC grid input voltage.", d["grid"].get("voltage_v")),
            ("walrus_output_voltage_volts", "AC output voltage.", d["output"].get("voltage_v")),
            ("walrus_load_percent", "Walrus reported AC load percentage.", d["output"].get("load_pct")),
            ("walrus_load_power_watts", "Derived AC house/load output power.", d["output"].get("load_power_w")),
            ("walrus_usage_today_kwh", "Locally integrated house/load energy today.", today.get("usage_kwh")),
            ("walrus_usage_last_30_days_kwh", "Locally integrated house/load energy over the last 30 days.", last30.get("usage_kwh")),
            ("walrus_system_temperature_celsius", "Walrus temperature in Celsius.", d["system"].get("temperature_c")),
            ("walrus_output_frequency_hz", "AC output frequency; may be profile nominal until a telemetry register is mapped.", d["output"].get("frequency_hz")),
            ("walrus_grid_power_watts", "Grid power; positive import and negative export when mapped.", d["grid"].get("power_w")),
            ("walrus_battery_current_amps", "Battery current when mapped.", d["battery"].get("current_a")),
            ("walrus_battery_power_watts", "Battery power; positive discharge and negative charge when mapped.", d["battery"].get("power_w")),
            ("walrus_grid_import_today_kwh", "Locally integrated grid import today.", today.get("grid_import_kwh")),
            ("walrus_grid_export_today_kwh", "Locally integrated grid export today.", today.get("grid_export_kwh")),
            ("walrus_battery_charge_today_kwh", "Locally integrated battery charge energy today.", today.get("battery_charge_kwh")),
            ("walrus_battery_discharge_today_kwh", "Locally integrated battery discharge energy today.", today.get("battery_discharge_kwh")),
            ("walrus_solar_self_use_percent", "Solar self-use percentage when grid export is mapped.", today.get("solar_self_use_pct")),
        ]
        for name, help_text, value in mapping:
            if value is None:
                continue
            lines.extend([f"# HELP {name} {help_text}", f"# TYPE {name} gauge", f"{name} {value}"])
        mode = d.get("system", {}).get("mode")
        if mode:
            safe_mode = str(mode).replace('"', '')
            lines.extend([
                "# HELP walrus_operating_mode Current normalized operating mode as a labeled gauge.",
                "# TYPE walrus_operating_mode gauge",
                f'walrus_operating_mode{{mode="{safe_mode}"}} 1',
            ])
        lines.extend([
            "# HELP walrus_grid_present Whether AC grid input is present (1/0).",
            "# TYPE walrus_grid_present gauge",
            f"walrus_grid_present {1 if d.get('grid', {}).get('present') else 0}",
            "# HELP walrus_telemetry_stale Whether the most recent telemetry is stale (1/0).",
            "# TYPE walrus_telemetry_stale gauge",
            f"walrus_telemetry_stale {1 if d.get('service', {}).get('telemetry_stale') else 0}",
            "# HELP walrus_modbus_timeouts_total Modbus response timeouts since service start.",
            "# TYPE walrus_modbus_timeouts_total counter",
            f"walrus_modbus_timeouts_total {self.state.timeouts}",
            "# HELP walrus_modbus_crc_errors_total Invalid Modbus CRCs since service start.",
            "# TYPE walrus_modbus_crc_errors_total counter",
            f"walrus_modbus_crc_errors_total {self.state.crc_errors}",
        ])
        return "\n".join(lines) + "\n"
