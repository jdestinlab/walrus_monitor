from __future__ import annotations

import json
import logging
import os
import threading
import time
from typing import Any
from urllib.error import URLError
from urllib.request import Request, urlopen


LOG = logging.getLogger("walrus-monitor.notify")


def _env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


class AlertNotifier:
    """Optional non-blocking Gotify and generic-webhook alert delivery."""

    def __init__(self) -> None:
        self.gotify_enabled = _env_bool("WALRUS_GOTIFY_ENABLED", False)
        self.gotify_url = os.getenv("WALRUS_GOTIFY_URL", "").rstrip("/")
        self.gotify_token = os.getenv("WALRUS_GOTIFY_TOKEN", "")
        self.webhook_enabled = _env_bool("WALRUS_WEBHOOK_ENABLED", False)
        self.webhook_url = os.getenv("WALRUS_WEBHOOK_URL", "")
        self.timeout = max(1.0, float(os.getenv("WALRUS_NOTIFY_TIMEOUT", "4")))
        self.cooldown_s = max(0.0, float(os.getenv("WALRUS_ALERT_COOLDOWN_SECONDS", "900")))
        self._last_sent: dict[str, float] = {}
        self._lock = threading.Lock()

    @property
    def enabled(self) -> bool:
        return (
            self.gotify_enabled
            and bool(self.gotify_url)
            and bool(self.gotify_token)
        ) or (
            self.webhook_enabled
            and bool(self.webhook_url)
        )

    def notify(
        self,
        *,
        code: str,
        severity: str,
        message: str,
        details: dict[str, Any] | None = None,
        cleared: bool = False,
    ) -> bool:
        if not self.enabled:
            return False

        now = time.monotonic()
        cooldown_key = f"{code}:{'cleared' if cleared else 'active'}"

        with self._lock:
            last = self._last_sent.get(cooldown_key)
            if last is not None and now - last < self.cooldown_s:
                return False
            self._last_sent[cooldown_key] = now

        payload = {
            "source": "walrus-monitor",
            "code": code,
            "severity": severity,
            "message": message,
            "cleared": cleared,
            "details": details or {},
        }

        threading.Thread(
            target=self._deliver,
            args=(payload,),
            name=f"walrus-notify-{code}",
            daemon=True,
        ).start()
        return True

    def _deliver(self, payload: dict[str, Any]) -> None:
        if self.gotify_enabled and self.gotify_url and self.gotify_token:
            self._send_gotify(payload)

        if self.webhook_enabled and self.webhook_url:
            self._send_webhook(payload)

    def _send_gotify(self, payload: dict[str, Any]) -> None:
        title = "Walrus Monitor"
        if payload.get("cleared"):
            title += " - Cleared"
        else:
            title += f" - {str(payload.get('severity', 'alert')).title()}"

        priority = 8 if payload.get("severity") == "alert" else 5

        body = {
            "title": title,
            "message": str(payload.get("message", "")),
            "priority": priority,
            "extras": {
                "client::display": {
                    "contentType": "text/plain",
                }
            },
        }

        url = f"{self.gotify_url}/message?token={self.gotify_token}"
        self._post_json(url, body, "Gotify")

    def _send_webhook(self, payload: dict[str, Any]) -> None:
        self._post_json(self.webhook_url, payload, "webhook")

    def _post_json(self, url: str, payload: dict[str, Any], label: str) -> None:
        data = json.dumps(payload, separators=(",", ":")).encode("utf-8")
        request = Request(
            url,
            data=data,
            method="POST",
            headers={
                "Content-Type": "application/json",
                "User-Agent": "walrus-monitor/0.6.0",
            },
        )

        try:
            with urlopen(request, timeout=self.timeout) as response:
                response.read(1024)
                if response.status < 200 or response.status >= 300:
                    LOG.warning("%s notification returned HTTP %s", label, response.status)
        except (OSError, URLError, ValueError) as exc:
            LOG.warning("%s notification failed: %s", label, exc)
