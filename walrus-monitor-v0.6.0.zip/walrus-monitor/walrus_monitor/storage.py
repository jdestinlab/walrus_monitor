from __future__ import annotations

import csv
from datetime import datetime, timedelta, timezone
from io import StringIO
import json
from pathlib import Path
import sqlite3
from typing import Any

from .tariff import RatePlan
from zoneinfo import ZoneInfo


SCHEMA_VERSION = 5


class Storage:
    def __init__(
        self,
        path: str,
        timezone_name: str = "UTC",
        raw_retention_days: int = 30,
        daily_retention_days: int = 1096,
        max_integration_gap_s: float = 120.0,
        legacy_energy_path: str | None = "/data/energy.json",
        backup_dir: str | None = None,
        backup_keep: int = 5,
        backup_retention_days: int = 30,
    ) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.timezone_name = timezone_name
        self.tz = ZoneInfo(timezone_name)
        self.raw_retention_days = max(1, int(raw_retention_days))
        self.daily_retention_days = max(30, int(daily_retention_days))
        self.max_integration_gap_s = float(max_integration_gap_s)
        self.legacy_energy_path = Path(legacy_energy_path) if legacy_energy_path else None
        self.backup_dir = Path(backup_dir) if backup_dir else (self.path.parent / "backups")
        self.backup_keep = max(1, int(backup_keep))
        self.backup_retention_days = max(1, int(backup_retention_days))
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.execute("PRAGMA busy_timeout=5000")
        self.conn.execute("PRAGMA wal_autocheckpoint=1000")
        self._migrate()
        self._import_legacy_energy_once()
        self._last_sample = self._load_last_sample()
        self._writes_since_purge = 0

    def close(self) -> None:
        self.conn.close()

    def _migrate(self) -> None:
        current = int(self.conn.execute("PRAGMA user_version").fetchone()[0])
        if current > SCHEMA_VERSION:
            raise RuntimeError(f"database schema {current} is newer than supported {SCHEMA_VERSION}")
        if current > 0 and current < SCHEMA_VERSION:
            self._backup_before_migration(current, SCHEMA_VERSION)

        if current < 1:
            self.conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS samples (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts_utc TEXT NOT NULL,
                    ts_local TEXT NOT NULL,
                    local_date TEXT NOT NULL,
                    pv_voltage_v REAL,
                    pv_current_a REAL,
                    pv_power_w REAL,
                    pv_energy_delta_kwh REAL NOT NULL DEFAULT 0,
                    battery_voltage_v REAL,
                    battery_soc_pct REAL,
                    estimated_stored_kwh REAL,
                    battery_current_a REAL,
                    battery_power_w REAL,
                    battery_power_source TEXT,
                    battery_charge_delta_kwh REAL,
                    battery_discharge_delta_kwh REAL,
                    grid_voltage_v REAL,
                    grid_power_w REAL,
                    grid_import_delta_kwh REAL,
                    grid_export_delta_kwh REAL,
                    grid_test_session_id INTEGER,
                    output_voltage_v REAL,
                    output_frequency_hz REAL,
                    operating_mode_raw INTEGER,
                    load_power_w REAL,
                    usage_delta_kwh REAL,
                    temperature_c REAL,
                    temperature_f REAL
                );
                CREATE INDEX IF NOT EXISTS idx_samples_ts_utc ON samples(ts_utc);
                CREATE INDEX IF NOT EXISTS idx_samples_local_date ON samples(local_date);

                CREATE TABLE IF NOT EXISTS daily_summary (
                    local_date TEXT PRIMARY KEY,
                    pv_generated_kwh REAL NOT NULL DEFAULT 0,
                    usage_kwh REAL,
                    grid_import_kwh REAL,
                    grid_export_kwh REAL,
                    battery_charge_kwh REAL,
                    battery_discharge_kwh REAL,
                    soc_min_pct REAL,
                    soc_max_pct REAL,
                    battery_voltage_min_v REAL,
                    battery_voltage_max_v REAL,
                    temperature_min_c REAL,
                    temperature_max_c REAL,
                    sample_count INTEGER NOT NULL DEFAULT 0,
                    first_sample_utc TEXT,
                    last_sample_utc TEXT
                );

                CREATE TABLE IF NOT EXISTS pv_interval_energy (
                    interval_start_utc TEXT PRIMARY KEY,
                    interval_start_local TEXT NOT NULL,
                    local_date TEXT NOT NULL,
                    pv_generated_kwh REAL NOT NULL DEFAULT 0,
                    sample_count INTEGER NOT NULL DEFAULT 0
                );
                CREATE INDEX IF NOT EXISTS idx_pv_interval_energy_local_date
                    ON pv_interval_energy(local_date);

                CREATE TABLE IF NOT EXISTS grid_test_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    started_utc TEXT NOT NULL,
                    started_local TEXT NOT NULL,
                    stopped_utc TEXT,
                    stopped_local TEXT,
                    label TEXT,
                    active INTEGER NOT NULL DEFAULT 1,
                    inverter_efficiency REAL,
                    inverter_idle_w REAL
                );
                CREATE INDEX IF NOT EXISTS idx_grid_test_sessions_active
                    ON grid_test_sessions(active);

                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts_utc TEXT NOT NULL,
                    ts_local TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    code TEXT NOT NULL,
                    message TEXT NOT NULL,
                    details_json TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_events_ts_utc ON events(ts_utc);
                """
            )
            current = 5
            self.conn.execute("PRAGMA user_version=5")
            self.conn.commit()

        if current == 1:
            sample_columns = {row[1] for row in self.conn.execute("PRAGMA table_info(samples)")}
            daily_columns = {row[1] for row in self.conn.execute("PRAGMA table_info(daily_summary)")}
            if "grid_export_delta_kwh" not in sample_columns:
                self.conn.execute("ALTER TABLE samples ADD COLUMN grid_export_delta_kwh REAL")
            if "output_frequency_hz" not in sample_columns:
                self.conn.execute("ALTER TABLE samples ADD COLUMN output_frequency_hz REAL")
            if "operating_mode_raw" not in sample_columns:
                self.conn.execute("ALTER TABLE samples ADD COLUMN operating_mode_raw INTEGER")
            if "grid_export_kwh" not in daily_columns:
                self.conn.execute("ALTER TABLE daily_summary ADD COLUMN grid_export_kwh REAL")
            self.conn.execute("PRAGMA user_version=2")
            self.conn.commit()
            current = 2

        if current == 2:
            sample_columns = {row[1] for row in self.conn.execute("PRAGMA table_info(samples)")}
            if "grid_test_session_id" not in sample_columns:
                self.conn.execute("ALTER TABLE samples ADD COLUMN grid_test_session_id INTEGER")
            self.conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS grid_test_sessions (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    started_utc TEXT NOT NULL,
                    started_local TEXT NOT NULL,
                    stopped_utc TEXT,
                    stopped_local TEXT,
                    label TEXT,
                    active INTEGER NOT NULL DEFAULT 1,
                    inverter_efficiency REAL,
                    inverter_idle_w REAL
                );
                CREATE INDEX IF NOT EXISTS idx_grid_test_sessions_active
                    ON grid_test_sessions(active);
                """
            )
            self.conn.execute("PRAGMA user_version=3")
            self.conn.commit()

        if current == 3:
            sample_columns = {
                row[1] for row in self.conn.execute("PRAGMA table_info(samples)")
            }
            if "battery_power_source" not in sample_columns:
                self.conn.execute(
                    "ALTER TABLE samples ADD COLUMN battery_power_source TEXT"
                )
            self.conn.execute("PRAGMA user_version=4")
            self.conn.commit()
            current = 4

        if current == 4:
            self.conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS pv_interval_energy (
                    interval_start_utc TEXT PRIMARY KEY,
                    interval_start_local TEXT NOT NULL,
                    local_date TEXT NOT NULL,
                    pv_generated_kwh REAL NOT NULL DEFAULT 0,
                    sample_count INTEGER NOT NULL DEFAULT 0
                );
                CREATE INDEX IF NOT EXISTS idx_pv_interval_energy_local_date
                    ON pv_interval_energy(local_date);
                """
            )

            buckets: dict[str, dict[str, Any]] = {}
            for row in self.conn.execute(
                "SELECT ts_local,pv_energy_delta_kwh FROM samples ORDER BY id"
            ).fetchall():
                local_dt = datetime.fromisoformat(str(row["ts_local"]))
                bucket_local = local_dt.replace(
                    minute=(local_dt.minute // 15) * 15,
                    second=0,
                    microsecond=0,
                )
                bucket_utc = bucket_local.astimezone(timezone.utc)
                key = bucket_utc.isoformat(timespec="seconds")
                bucket = buckets.setdefault(
                    key,
                    {
                        "interval_start_local": bucket_local.isoformat(timespec="seconds"),
                        "local_date": bucket_local.date().isoformat(),
                        "pv_generated_kwh": 0.0,
                        "sample_count": 0,
                    },
                )
                bucket["pv_generated_kwh"] += float(row["pv_energy_delta_kwh"] or 0.0)
                bucket["sample_count"] += 1

            self.conn.executemany(
                """
                INSERT INTO pv_interval_energy(
                    interval_start_utc,interval_start_local,local_date,
                    pv_generated_kwh,sample_count
                ) VALUES(?,?,?,?,?)
                ON CONFLICT(interval_start_utc) DO UPDATE SET
                    interval_start_local=excluded.interval_start_local,
                    local_date=excluded.local_date,
                    pv_generated_kwh=excluded.pv_generated_kwh,
                    sample_count=excluded.sample_count
                """,
                [
                    (
                        key,
                        value["interval_start_local"],
                        value["local_date"],
                        value["pv_generated_kwh"],
                        value["sample_count"],
                    )
                    for key, value in buckets.items()
                ],
            )
            self.conn.execute("PRAGMA user_version=5")
            self.conn.commit()
            current = 5

    def _backup_before_migration(self, current: int, target: int) -> Path:
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        backup_path = self.backup_dir / f"walrus-schema-{current}-to-{target}-{stamp}.db"
        dest = sqlite3.connect(backup_path)
        try:
            self.conn.backup(dest)
            dest.commit()
        finally:
            dest.close()
        self._prune_backups()
        return backup_path

    def _prune_backups(self) -> None:
        if not self.backup_dir.exists():
            return
        backups = sorted(
            self.backup_dir.glob("walrus-schema-*.db"),
            key=lambda x: x.stat().st_mtime,
            reverse=True,
        )
        for old in backups[self.backup_keep:]:
            try:
                old.unlink()
            except FileNotFoundError:
                pass

    def latest_backup(self) -> str | None:
        if not self.backup_dir.exists():
            return None
        backups = sorted(
            self.backup_dir.glob("walrus-schema-*.db"),
            key=lambda x: x.stat().st_mtime,
            reverse=True,
        )
        return str(backups[0]) if backups else None

    def _import_legacy_energy_once(self) -> None:
        if self.get_meta("legacy_energy_imported") == "1":
            return
        existing = self.get_meta("pv_generated_since_baseline_kwh")
        if existing is None and self.legacy_energy_path and self.legacy_energy_path.exists():
            try:
                data = json.loads(self.legacy_energy_path.read_text())
                value = max(0.0, float(data.get("pv_generated_since_base_kwh", 0.0)))
                self.set_meta("pv_generated_since_baseline_kwh", f"{value:.9f}")
            except Exception:
                pass
        if self.get_meta("pv_generated_since_baseline_kwh") is None:
            self.set_meta("pv_generated_since_baseline_kwh", "0.0")
        self.set_meta("legacy_energy_imported", "1")

    def get_meta(self, key: str) -> str | None:
        row = self.conn.execute("SELECT value FROM meta WHERE key=?", (key,)).fetchone()
        return str(row[0]) if row else None

    def set_meta(self, key: str, value: str) -> None:
        self.conn.execute(
            "INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )
        self.conn.commit()

    def pv_generated_since_baseline_kwh(self) -> float:
        return float(self.get_meta("pv_generated_since_baseline_kwh") or "0")

    def _load_last_sample(self) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT ts_utc,pv_power_w,load_power_w,grid_power_w,battery_power_w,"
            "battery_power_source,grid_test_session_id "
            "FROM samples ORDER BY id DESC LIMIT 1"
        ).fetchone()
        return dict(row) if row else None

    def active_grid_test_session_id(self) -> int | None:
        row = self.conn.execute(
            "SELECT id FROM grid_test_sessions WHERE active=1 ORDER BY id DESC LIMIT 1"
        ).fetchone()
        return int(row[0]) if row else None

    @staticmethod
    def _energy_delta(previous_w: float | None, current_w: float | None, elapsed_s: float) -> float | None:
        if previous_w is None or current_w is None:
            return None
        return ((float(previous_w) + float(current_w)) / 2.0) * elapsed_s / 3_600_000.0

    @staticmethod
    def _signed_energy_parts(
        previous_w: float | None, current_w: float | None, elapsed_s: float
    ) -> tuple[float | None, float | None]:
        """Integrate a linearly changing signed power signal without canceling zero crossings.

        Returns (positive_kwh, negative_magnitude_kwh). This matters for future grid and
        battery power mappings: an interval that changes from import to export, or from
        discharge to charge, should contribute to both counters rather than netting to zero.
        """
        if previous_w is None or current_w is None:
            return None, None
        a, b = float(previous_w), float(current_w)
        if elapsed_s <= 0:
            return 0.0, 0.0
        scale = elapsed_s / 3_600_000.0
        if a >= 0 and b >= 0:
            return (a + b) / 2.0 * scale, 0.0
        if a <= 0 and b <= 0:
            return 0.0, -(a + b) / 2.0 * scale
        # Linear interpolation crosses zero once inside the interval. Split the two triangles.
        frac = abs(a) / (abs(a) + abs(b))
        if a > 0:
            positive = 0.5 * a * (elapsed_s * frac) / 3_600_000.0
            negative = 0.5 * abs(b) * (elapsed_s * (1.0 - frac)) / 3_600_000.0
        else:
            negative = 0.5 * abs(a) * (elapsed_s * frac) / 3_600_000.0
            positive = 0.5 * b * (elapsed_s * (1.0 - frac)) / 3_600_000.0
        return positive, negative

    def record_sample(self, sample: dict[str, Any], now: datetime | None = None) -> dict[str, Any]:
        now = now or datetime.now(timezone.utc)
        local = now.astimezone(self.tz)
        ts_utc = now.isoformat(timespec="seconds")
        ts_local = local.isoformat(timespec="seconds")
        local_date = local.date().isoformat()

        elapsed_s: float | None = None
        if self._last_sample:
            try:
                previous_dt = datetime.fromisoformat(str(self._last_sample["ts_utc"]))
                elapsed_s = (now - previous_dt).total_seconds()
            except Exception:
                elapsed_s = None
        if elapsed_s is None or elapsed_s <= 0 or elapsed_s > self.max_integration_gap_s:
            elapsed_s = 0.0

        pv_delta = self._energy_delta(
            self._last_sample.get("pv_power_w") if self._last_sample else None,
            sample.get("pv_power_w"),
            elapsed_s,
        )
        usage_delta = self._energy_delta(
            self._last_sample.get("load_power_w") if self._last_sample else None,
            sample.get("load_power_w"),
            elapsed_s,
        )
        previous_battery_source = (
            self._last_sample.get("battery_power_source")
            if self._last_sample else None
        )
        current_battery_source = sample.get("battery_power_source")

        battery_energy_excluded = (
            previous_battery_source == "estimated_grid_charger_setpoint"
            or current_battery_source == "estimated_grid_charger_setpoint"
        )

        if battery_energy_excluded:
            # The AC charger-current setting is a configured setpoint, not
            # measured delivered battery power. Keep it available for live
            # display, but never integrate it into historical battery kWh.
            # Also skip transition intervals so estimated and integrable
            # battery-power sources are never blended together.
            battery_discharge_delta, battery_charge_delta = 0.0, 0.0
        else:
            battery_discharge_delta, battery_charge_delta = self._signed_energy_parts(
                self._last_sample.get("battery_power_w") if self._last_sample else None,
                sample.get("battery_power_w"),
                elapsed_s,
            )
        grid_test_session_id = self.active_grid_test_session_id()
        previous_grid_test_session_id = (
            self._last_sample.get("grid_test_session_id") if self._last_sample else None
        )
        if previous_grid_test_session_id != grid_test_session_id:
            # Do not integrate the boundary interval when entering or leaving a test.
            grid_import_delta, grid_export_delta = 0.0, 0.0
        else:
            grid_import_delta, grid_export_delta = self._signed_energy_parts(
                self._last_sample.get("grid_power_w") if self._last_sample else None,
                sample.get("grid_power_w"),
                elapsed_s,
            )

        pv_delta_value = max(0.0, pv_delta or 0.0)
        if pv_delta_value:
            total = self.pv_generated_since_baseline_kwh() + pv_delta_value
            self.conn.execute(
                "INSERT INTO meta(key,value) VALUES('pv_generated_since_baseline_kwh',?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                (f"{total:.9f}",),
            )

        columns = {
            "ts_utc": ts_utc,
            "ts_local": ts_local,
            "local_date": local_date,
            "pv_voltage_v": sample.get("pv_voltage_v"),
            "pv_current_a": sample.get("pv_current_a"),
            "pv_power_w": sample.get("pv_power_w"),
            "pv_energy_delta_kwh": pv_delta_value,
            "battery_voltage_v": sample.get("battery_voltage_v"),
            "battery_soc_pct": sample.get("battery_soc_pct"),
            "estimated_stored_kwh": sample.get("estimated_stored_kwh"),
            "battery_current_a": sample.get("battery_current_a"),
            "battery_power_w": sample.get("battery_power_w"),
            "battery_power_source": sample.get("battery_power_source"),
            "battery_charge_delta_kwh": battery_charge_delta,
            "battery_discharge_delta_kwh": battery_discharge_delta,
            "grid_voltage_v": sample.get("grid_voltage_v"),
            "grid_power_w": sample.get("grid_power_w"),
            "grid_import_delta_kwh": grid_import_delta,
            "grid_export_delta_kwh": grid_export_delta,
            "grid_test_session_id": grid_test_session_id,
            "output_voltage_v": sample.get("output_voltage_v"),
            "output_frequency_hz": sample.get("output_frequency_hz"),
            "operating_mode_raw": sample.get("operating_mode_raw"),
            "load_power_w": sample.get("load_power_w"),
            "usage_delta_kwh": max(0.0, usage_delta) if usage_delta is not None else None,
            "temperature_c": sample.get("temperature_c"),
            "temperature_f": sample.get("temperature_f"),
        }
        names = ",".join(columns)
        placeholders = ",".join("?" for _ in columns)
        self.conn.execute(
            f"INSERT INTO samples({names}) VALUES({placeholders})",
            tuple(columns.values()),
        )
        daily_columns = dict(columns)
        if grid_test_session_id is not None:
            # Test-session Grid energy is retained in raw samples for export,
            # but excluded from normal daily and long-term Grid totals.
            daily_columns["grid_import_delta_kwh"] = None
            daily_columns["grid_export_delta_kwh"] = None
        self._upsert_daily(daily_columns)
        self._upsert_pv_interval_energy(local, pv_delta_value)
        self.conn.commit()

        self._last_sample = {
            "ts_utc": ts_utc,
            "pv_power_w": sample.get("pv_power_w"),
            "load_power_w": sample.get("load_power_w"),
            "grid_power_w": sample.get("grid_power_w"),
            "battery_power_w": sample.get("battery_power_w"),
            "battery_power_source": sample.get("battery_power_source"),
            "grid_test_session_id": grid_test_session_id,
        }
        self._writes_since_purge += 1
        if self._writes_since_purge >= 240:
            self.purge()
            self._writes_since_purge = 0
        return columns

    def _upsert_daily(self, c: dict[str, Any]) -> None:
        date = c["local_date"]
        existing = self.conn.execute("SELECT * FROM daily_summary WHERE local_date=?", (date,)).fetchone()
        if existing is None:
            self.conn.execute(
                """
                INSERT INTO daily_summary(
                    local_date,pv_generated_kwh,usage_kwh,grid_import_kwh,grid_export_kwh,
                    battery_charge_kwh,battery_discharge_kwh,soc_min_pct,soc_max_pct,
                    battery_voltage_min_v,battery_voltage_max_v,temperature_min_c,
                    temperature_max_c,sample_count,first_sample_utc,last_sample_utc
                ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                """,
                (
                    date,
                    c["pv_energy_delta_kwh"],
                    c["usage_delta_kwh"],
                    c["grid_import_delta_kwh"],
                    c["grid_export_delta_kwh"],
                    c["battery_charge_delta_kwh"],
                    c["battery_discharge_delta_kwh"],
                    c["battery_soc_pct"],
                    c["battery_soc_pct"],
                    c["battery_voltage_v"],
                    c["battery_voltage_v"],
                    c["temperature_c"],
                    c["temperature_c"],
                    1,
                    c["ts_utc"],
                    c["ts_utc"],
                ),
            )
            return

        def add_nullable(old: Any, delta: Any) -> Any:
            if delta is None:
                return old
            return float(old or 0.0) + float(delta)

        def min_nullable(old: Any, value: Any) -> Any:
            if value is None:
                return old
            return value if old is None else min(float(old), float(value))

        def max_nullable(old: Any, value: Any) -> Any:
            if value is None:
                return old
            return value if old is None else max(float(old), float(value))

        self.conn.execute(
            """
            UPDATE daily_summary SET
                pv_generated_kwh=?, usage_kwh=?, grid_import_kwh=?, grid_export_kwh=?,
                battery_charge_kwh=?, battery_discharge_kwh=?, soc_min_pct=?, soc_max_pct=?,
                battery_voltage_min_v=?, battery_voltage_max_v=?, temperature_min_c=?,
                temperature_max_c=?, sample_count=sample_count+1, last_sample_utc=?
            WHERE local_date=?
            """,
            (
                float(existing["pv_generated_kwh"] or 0.0) + float(c["pv_energy_delta_kwh"] or 0.0),
                add_nullable(existing["usage_kwh"], c["usage_delta_kwh"]),
                add_nullable(existing["grid_import_kwh"], c["grid_import_delta_kwh"]),
                add_nullable(existing["grid_export_kwh"], c["grid_export_delta_kwh"]),
                add_nullable(existing["battery_charge_kwh"], c["battery_charge_delta_kwh"]),
                add_nullable(existing["battery_discharge_kwh"], c["battery_discharge_delta_kwh"]),
                min_nullable(existing["soc_min_pct"], c["battery_soc_pct"]),
                max_nullable(existing["soc_max_pct"], c["battery_soc_pct"]),
                min_nullable(existing["battery_voltage_min_v"], c["battery_voltage_v"]),
                max_nullable(existing["battery_voltage_max_v"], c["battery_voltage_v"]),
                min_nullable(existing["temperature_min_c"], c["temperature_c"]),
                max_nullable(existing["temperature_max_c"], c["temperature_c"]),
                c["ts_utc"],
                date,
            ),
        )

    def _upsert_pv_interval_energy(
        self,
        local_dt: datetime,
        pv_delta_kwh: float,
    ) -> None:
        bucket_local = local_dt.replace(
            minute=(local_dt.minute // 15) * 15,
            second=0,
            microsecond=0,
        )
        bucket_utc = bucket_local.astimezone(timezone.utc)
        self.conn.execute(
            """
            INSERT INTO pv_interval_energy(
                interval_start_utc,interval_start_local,local_date,
                pv_generated_kwh,sample_count
            ) VALUES(?,?,?,?,1)
            ON CONFLICT(interval_start_utc) DO UPDATE SET
                interval_start_local=excluded.interval_start_local,
                local_date=excluded.local_date,
                pv_generated_kwh=pv_interval_energy.pv_generated_kwh
                    + excluded.pv_generated_kwh,
                sample_count=pv_interval_energy.sample_count + 1
            """,
            (
                bucket_utc.isoformat(timespec="seconds"),
                bucket_local.isoformat(timespec="seconds"),
                bucket_local.date().isoformat(),
                max(0.0, float(pv_delta_kwh)),
            ),
        )

    def log_event(self, severity: str, code: str, message: str, details: dict[str, Any] | None = None) -> None:
        now = datetime.now(timezone.utc)
        self.conn.execute(
            "INSERT INTO events(ts_utc,ts_local,severity,code,message,details_json) VALUES(?,?,?,?,?,?)",
            (
                now.isoformat(timespec="seconds"),
                now.astimezone(self.tz).isoformat(timespec="seconds"),
                severity,
                code,
                message,
                json.dumps(details, separators=(",", ":")) if details else None,
            ),
        )
        self.conn.commit()

    def events(self, limit: int = 100) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT ts_utc,ts_local,severity,code,message,details_json FROM events ORDER BY id DESC LIMIT ?",
            (max(1, min(int(limit), 1000)),),
        ).fetchall()
        out: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            if item.get("details_json"):
                try:
                    item["details"] = json.loads(item.pop("details_json"))
                except Exception:
                    pass
            else:
                item.pop("details_json", None)
            out.append(item)
        return out

    def all_events(self) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            "SELECT ts_utc,ts_local,severity,code,message,details_json "
            "FROM events ORDER BY id"
        ).fetchall()
        out: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            if item.get("details_json"):
                try:
                    item["details"] = json.loads(item.pop("details_json"))
                except Exception:
                    pass
            else:
                item.pop("details_json", None)
            out.append(item)
        return out

    def events_csv(self) -> str:
        rows = self.all_events()
        fields = ["ts_utc", "ts_local", "severity", "code", "message", "details_json"]
        output = StringIO()
        writer = csv.DictWriter(
            output,
            fieldnames=fields,
            extrasaction="ignore",
            lineterminator="\\r\\n",
        )
        writer.writeheader()
        for row in rows:
            item = dict(row)
            details = item.pop("details", None)
            item["details_json"] = (
                json.dumps(details, separators=(",", ":"), ensure_ascii=False)
                if details is not None
                else ""
            )
            writer.writerow(item)
        return output.getvalue()

    def events_json(self) -> str:
        return json.dumps(
            {"events": self.all_events()},
            indent=2,
            ensure_ascii=False,
        ) + "\\n"

    def _prune_routine_backups(self) -> int:
        """Remove routine Walrus backups older than the configured retention.

        Schema-migration backups are intentionally excluded.
        """
        if not self.backup_dir.exists():
            return 0

        cutoff = datetime.now(timezone.utc) - timedelta(days=self.backup_retention_days)
        patterns = (
            "walrus-events-*.csv",
            "walrus-events-*.json",
            "walrus-pre-reset-*.db",
            "walrus-manual-*.db",
        )

        removed = 0
        for pattern in patterns:
            for path in self.backup_dir.glob(pattern):
                try:
                    modified = datetime.fromtimestamp(path.stat().st_mtime, timezone.utc)
                    if modified < cutoff:
                        path.unlink()
                        removed += 1
                except FileNotFoundError:
                    continue
        return removed

    def backup_events(self) -> dict[str, str]:
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        csv_path = self.backup_dir / f"walrus-events-{stamp}.csv"
        json_path = self.backup_dir / f"walrus-events-{stamp}.json"
        csv_path.write_text(self.events_csv(), encoding="utf-8")
        json_path.write_text(self.events_json(), encoding="utf-8")
        self._prune_routine_backups()
        return {"csv": str(csv_path), "json": str(json_path)}

    def clear_events(self, backup_first: bool = True) -> dict[str, Any]:
        backup = self.backup_events() if backup_first else None
        count = int(
            self.conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        )
        self.conn.execute("DELETE FROM events")
        self.conn.commit()
        return {"cleared": count, "backup": backup}

    def grid_test_session(self, session_id: int) -> dict[str, Any] | None:
        row = self.conn.execute(
            "SELECT id,started_utc,started_local,stopped_utc,stopped_local,label,active,"
            "inverter_efficiency,inverter_idle_w FROM grid_test_sessions WHERE id=?",
            (int(session_id),),
        ).fetchone()
        return dict(row) if row else None

    def grid_test_session_status(self) -> dict[str, Any]:
        row = self.conn.execute(
            "SELECT id,started_utc,started_local,stopped_utc,stopped_local,label,active,"
            "inverter_efficiency,inverter_idle_w FROM grid_test_sessions "
            "WHERE active=1 ORDER BY id DESC LIMIT 1"
        ).fetchone()
        return {"active": row is not None, "session": dict(row) if row else None}

    def start_grid_test_session(
        self,
        inverter_efficiency: float,
        inverter_idle_w: float,
        label: str | None = None,
    ) -> dict[str, Any]:
        if self.active_grid_test_session_id() is not None:
            raise RuntimeError("A Grid test session is already active")
        now = datetime.now(timezone.utc)
        local = now.astimezone(self.tz)
        clean_label = (label or "").strip()[:120] or None
        cur = self.conn.execute(
            "INSERT INTO grid_test_sessions("
            "started_utc,started_local,label,active,inverter_efficiency,inverter_idle_w"
            ") VALUES(?,?,?,?,?,?)",
            (
                now.isoformat(timespec="seconds"),
                local.isoformat(timespec="seconds"),
                clean_label,
                1,
                float(inverter_efficiency),
                float(inverter_idle_w),
            ),
        )
        self.conn.commit()
        session_id = int(cur.lastrowid)
        return self.grid_test_session(session_id) or {"id": session_id, "active": 1}

    def stop_grid_test_session(self) -> dict[str, Any]:
        session_id = self.active_grid_test_session_id()
        if session_id is None:
            raise RuntimeError("No Grid test session is active")
        now = datetime.now(timezone.utc)
        local = now.astimezone(self.tz)
        self.conn.execute(
            "UPDATE grid_test_sessions SET active=0,stopped_utc=?,stopped_local=? WHERE id=?",
            (
                now.isoformat(timespec="seconds"),
                local.isoformat(timespec="seconds"),
                session_id,
            ),
        )
        self.conn.commit()
        return self.grid_test_session(session_id) or {"id": session_id, "active": 0}

    def grid_test_session_rows(self, session_id: int) -> list[dict[str, Any]]:
        rows = self.conn.execute(
            """
            SELECT
                ts_utc,ts_local,local_date,
                grid_voltage_v,grid_power_w,grid_import_delta_kwh,grid_export_delta_kwh,
                load_power_w,
                pv_voltage_v,pv_current_a,pv_power_w,
                battery_voltage_v,battery_soc_pct,estimated_stored_kwh,
                battery_current_a,battery_power_w,
                battery_charge_delta_kwh,battery_discharge_delta_kwh,
                output_voltage_v,output_frequency_hz,operating_mode_raw,
                temperature_c,temperature_f
            FROM samples
            WHERE grid_test_session_id=?
            ORDER BY id
            """,
            (int(session_id),),
        ).fetchall()
        return [dict(row) for row in rows]

    def grid_test_session_csv(self, session_id: int) -> str:
        session = self.grid_test_session(session_id)
        if session is None:
            raise ValueError("Grid test session not found")
        rows = self.grid_test_session_rows(session_id)
        fields = [
            "ts_utc", "ts_local", "local_date",
            "grid_voltage_v", "grid_power_w", "grid_import_delta_kwh", "grid_export_delta_kwh",
            "load_power_w",
            "pv_voltage_v", "pv_current_a", "pv_power_w",
            "battery_voltage_v", "battery_soc_pct", "estimated_stored_kwh",
            "battery_current_a", "battery_power_w",
            "battery_charge_delta_kwh", "battery_discharge_delta_kwh",
            "output_voltage_v", "output_frequency_hz", "operating_mode_raw",
            "temperature_c", "temperature_f",
        ]
        output = StringIO()
        writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore", lineterminator="\r\n")
        writer.writeheader()
        writer.writerows(rows)
        return output.getvalue()

    def grid_test_session_json(self, session_id: int) -> str:
        session = self.grid_test_session(session_id)
        if session is None:
            raise ValueError("Grid test session not found")
        return json.dumps(
            {
                "session": session,
                "note": "Grid power is estimated; test-session Grid energy is excluded from normal long-term Grid totals.",
                "samples": self.grid_test_session_rows(session_id),
            },
            indent=2,
            ensure_ascii=False,
        ) + "\n"

    def reset_grid_history(self) -> dict[str, Any]:
        if self.active_grid_test_session_id() is not None:
            raise RuntimeError("Stop the active Grid test session before resetting Grid history")
        backup_path = self.backup_database("pre-grid-reset")
        sample_count = int(
            self.conn.execute(
                "SELECT COUNT(*) FROM samples WHERE grid_test_session_id IS NULL "
                "AND (grid_power_w IS NOT NULL OR grid_import_delta_kwh IS NOT NULL "
                "OR grid_export_delta_kwh IS NOT NULL)"
            ).fetchone()[0]
        )
        daily_count = int(
            self.conn.execute(
                "SELECT COUNT(*) FROM daily_summary "
                "WHERE grid_import_kwh IS NOT NULL OR grid_export_kwh IS NOT NULL"
            ).fetchone()[0]
        )
        self.conn.execute(
            "UPDATE samples SET grid_power_w=NULL,grid_import_delta_kwh=NULL,grid_export_delta_kwh=NULL "
            "WHERE grid_test_session_id IS NULL"
        )
        self.conn.execute(
            "UPDATE daily_summary SET grid_import_kwh=NULL,grid_export_kwh=NULL"
        )
        self.conn.commit()
        if self._last_sample is not None:
            self._last_sample["grid_power_w"] = None
        return {
            "backup": str(backup_path),
            "cleared": {
                "normal_grid_sample_rows": sample_count,
                "daily_grid_rows": daily_count,
            },
            "test_sessions_preserved": True,
        }

    def backup_database(self, label: str = "manual") -> Path:
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        safe_label = "".join(
            ch for ch in label if ch.isalnum() or ch in "-_"
        ) or "manual"
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        backup_path = self.backup_dir / f"walrus-{safe_label}-{stamp}.db"
        dest = sqlite3.connect(backup_path)
        try:
            self.conn.backup(dest)
            dest.commit()
        finally:
            dest.close()
        self._prune_routine_backups()
        return backup_path

    def reset_monitoring_data(self) -> dict[str, Any]:
        backup_path = self.backup_database("pre-reset")
        counts = {
            "samples": int(
                self.conn.execute("SELECT COUNT(*) FROM samples").fetchone()[0]
            ),
            "daily_summary": int(
                self.conn.execute("SELECT COUNT(*) FROM daily_summary").fetchone()[0]
            ),
            "events": int(
                self.conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
            ),
        }

        self.conn.execute("DELETE FROM samples")
        self.conn.execute("DELETE FROM daily_summary")
        self.conn.execute("DELETE FROM events")
        self.conn.execute(
            "INSERT INTO meta(key,value) "
            "VALUES('pv_generated_since_baseline_kwh','0.0') "
            "ON CONFLICT(key) DO UPDATE SET value='0.0'"
        )
        self.conn.commit()

        self._last_sample = None
        self._writes_since_purge = 0

        return {
            "backup": str(backup_path),
            "cleared": counts,
        }

    def daily(self, days: int = 30, poll_interval_s: float = 15.0) -> list[dict[str, Any]]:
        days = max(1, min(int(days), 3660))
        end = datetime.now(self.tz).date()
        start = end - timedelta(days=days - 1)
        rows = {
            row["local_date"]: dict(row)
            for row in self.conn.execute(
                "SELECT * FROM daily_summary WHERE local_date>=? AND local_date<=? ORDER BY local_date",
                (start.isoformat(), end.isoformat()),
            ).fetchall()
        }
        result: list[dict[str, Any]] = []
        expected_full_day = max(1.0, 86400.0 / max(1.0, poll_interval_s))
        for offset in range(days):
            date = start + timedelta(days=offset)
            key = date.isoformat()
            row = rows.get(key)
            if row is None:
                result.append(
                    {
                        "date": key,
                        "pv_generated_kwh": 0.0,
                        "usage_kwh": None,
                        "grid_import_kwh": None,
                        "grid_export_kwh": None,
                        "battery_charge_kwh": None,
                        "battery_discharge_kwh": None,
                        "soc_min_pct": None,
                        "soc_max_pct": None,
                        "temperature_min_c": None,
                        "temperature_max_c": None,
                        "sample_count": 0,
                        "data_coverage_pct": 0.0,
                    }
                )
                continue
            expected = expected_full_day
            if date == end:
                local_now = datetime.now(self.tz)
                seconds = local_now.hour * 3600 + local_now.minute * 60 + local_now.second
                expected = max(1.0, seconds / max(1.0, poll_interval_s))
            row["date"] = row.pop("local_date")
            row["pv_generated_kwh"] = round(float(row["pv_generated_kwh"] or 0.0), 4)
            for field in (
                "usage_kwh",
                "grid_import_kwh",
                "grid_export_kwh",
                "battery_charge_kwh",
                "battery_discharge_kwh",
            ):
                if row[field] is not None:
                    row[field] = round(float(row[field]), 4)
            row["data_coverage_pct"] = round(min(100.0, float(row["sample_count"]) / expected * 100.0), 1)
            result.append(row)
        return result

    def energy_summary(self, poll_interval_s: float = 15.0) -> dict[str, Any]:
        daily = self.daily(30, poll_interval_s=poll_interval_s)
        today = daily[-1]
        yesterday = daily[-2] if len(daily) > 1 else None

        def sum_nullable(field: str) -> float | None:
            values = [float(x[field]) for x in daily if x.get(field) is not None]
            return round(sum(values), 3) if values else None

        last30 = {
            "pv_generated_kwh": round(sum(float(x["pv_generated_kwh"]) for x in daily), 3),
            "usage_kwh": sum_nullable("usage_kwh"),
            "grid_import_kwh": sum_nullable("grid_import_kwh"),
            "grid_export_kwh": sum_nullable("grid_export_kwh"),
            "battery_charge_kwh": sum_nullable("battery_charge_kwh"),
            "battery_discharge_kwh": sum_nullable("battery_discharge_kwh"),
        }
        for bucket in (today, yesterday, last30):
            if not bucket:
                continue
            pv = bucket.get("pv_generated_kwh")
            export = bucket.get("grid_export_kwh")
            if pv is not None and export is not None and float(pv) > 0:
                self_use = max(0.0, float(pv) - float(export))
                bucket["solar_self_use_kwh"] = round(self_use, 3)
                bucket["solar_self_use_pct"] = round(min(100.0, self_use / float(pv) * 100.0), 1)
            else:
                bucket["solar_self_use_kwh"] = None
                bucket["solar_self_use_pct"] = None
            imp = bucket.get("grid_import_kwh")
            if imp is not None and export is not None:
                bucket["net_grid_kwh"] = round(float(imp) - float(export), 3)
            else:
                bucket["net_grid_kwh"] = None

        avg_row = self.conn.execute(
            "SELECT AVG(load_power_w) FROM samples WHERE local_date=? AND load_power_w IS NOT NULL",
            (today["date"],),
        ).fetchone()
        today["avg_load_w"] = (
            round(float(avg_row[0]), 1)
            if avg_row is not None and avg_row[0] is not None
            else None
        )

        return {"today": today, "yesterday": yesterday, "last_30_days": last30}

    def solar_savings_summary(
        self,
        plan: RatePlan,
        historical_pv_kwh: float = 0.0,
        historical_savings: float = 0.0,
        historical_label: str | None = None,
    ) -> dict[str, Any]:
        local_now = datetime.now(self.tz)
        today = local_now.date()
        month_start = today.replace(day=1)
        year_start = today.replace(month=1, day=1)
        start_date = plan.savings_start_date

        rows = self.conn.execute(
            """
            SELECT interval_start_local,pv_generated_kwh,sample_count
            FROM pv_interval_energy
            ORDER BY interval_start_utc
            """
        ).fetchall()

        totals = {
            "today": {"pv_kwh": 0.0, "savings": 0.0},
            "month_to_date": {"pv_kwh": 0.0, "savings": 0.0},
            "year_to_date": {"pv_kwh": 0.0, "savings": 0.0},
            "since_start": {"pv_kwh": 0.0, "savings": 0.0},
        }
        by_period: dict[str, dict[str, float]] = {}
        first_used: datetime | None = None
        last_used: datetime | None = None
        interval_count = 0
        sample_count = 0

        for row in rows:
            local_dt = datetime.fromisoformat(str(row["interval_start_local"]))
            if not plan.active_for(local_dt):
                continue

            pv_kwh = max(0.0, float(row["pv_generated_kwh"] or 0.0))
            components = plan.rate_components_at(local_dt)
            rate = float(components["variable_rate_per_kwh"])
            value = pv_kwh * rate
            local_date = local_dt.date()

            if first_used is None:
                first_used = local_dt
            last_used = local_dt
            interval_count += 1
            sample_count += int(row["sample_count"] or 0)

            totals["since_start"]["pv_kwh"] += pv_kwh
            totals["since_start"]["savings"] += value

            if local_date == today:
                totals["today"]["pv_kwh"] += pv_kwh
                totals["today"]["savings"] += value
            if local_date >= month_start:
                totals["month_to_date"]["pv_kwh"] += pv_kwh
                totals["month_to_date"]["savings"] += value
            if local_date >= year_start:
                totals["year_to_date"]["pv_kwh"] += pv_kwh
                totals["year_to_date"]["savings"] += value

            period_name = str(components["period"])
            bucket = by_period.setdefault(
                period_name,
                {"pv_kwh": 0.0, "savings": 0.0},
            )
            bucket["pv_kwh"] += pv_kwh
            bucket["savings"] += value

        for bucket in totals.values():
            bucket["pv_kwh"] = round(bucket["pv_kwh"], 4)
            bucket["savings"] = round(bucket["savings"], 2)

        for bucket in by_period.values():
            bucket["pv_kwh"] = round(bucket["pv_kwh"], 4)
            bucket["savings"] = round(bucket["savings"], 2)

        annualized_savings: float | None = None
        payback_years: float | None = None
        measurement_days: float | None = None

        if first_used is not None and last_used is not None:
            end_dt = max(last_used, local_now)
            measurement_days = max(
                1.0,
                (end_dt - first_used).total_seconds() / 86400.0,
            )
            annualized_savings = (
                totals["since_start"]["savings"] / measurement_days * 365.2425
            )
            annualized_savings = round(annualized_savings, 2)

            if (
                plan.system_cost is not None
                and plan.system_cost > 0
                and annualized_savings > 0
            ):
                payback_years = round(
                    float(plan.system_cost) / annualized_savings,
                    2,
                )

        historical_pv_kwh = max(0.0, float(historical_pv_kwh))
        historical_savings = max(0.0, float(historical_savings))
        measured_pv_kwh = float(totals["since_start"]["pv_kwh"])
        measured_savings = float(totals["since_start"]["savings"])
        combined_pv_kwh = historical_pv_kwh + measured_pv_kwh
        combined_savings = historical_savings + measured_savings

        remaining_cost = None
        payback_progress_pct = None
        remaining_payback_years = None
        if plan.system_cost is not None and plan.system_cost > 0:
            remaining_cost = max(0.0, float(plan.system_cost) - combined_savings)
            payback_progress_pct = min(
                100.0,
                combined_savings / float(plan.system_cost) * 100.0,
            )
            if annualized_savings is not None and annualized_savings > 0:
                remaining_payback_years = remaining_cost / annualized_savings

        return {
            "rate_plan": plan.to_dict(),
            "units": {
                "energy": "kWh",
                "currency": plan.currency,
                "energy_rate": f"{plan.currency}/kWh",
                "fixed_daily_charge": f"{plan.currency}/day",
                "system_cost": plan.currency,
                "savings": plan.currency,
                "annualized_savings": f"{plan.currency}/year",
                "measurement_duration": "days",
                "simple_payback": "years",
            },
            "estimate_method": "measured_pv_energy_x_time_of_use_variable_rate",
            "fixed_charge_included_in_savings": False,
            "fixed_charge_note": (
                "Fixed utility charges are shown as plan information but are "
                "not counted as avoided solar energy cost."
            ),
            "measurement_start_local": (
                first_used.isoformat(timespec="seconds")
                if first_used is not None
                else None
            ),
            "measurement_end_local": (
                last_used.isoformat(timespec="seconds")
                if last_used is not None
                else None
            ),
            "measurement_days": (
                round(measurement_days, 3)
                if measurement_days is not None
                else None
            ),
            "interval_count": interval_count,
            "sample_count": sample_count,
            **totals,
            "by_period": by_period,
            "annualized_savings": annualized_savings,
            "simple_payback_years": payback_years,
            "remaining_payback_years": (
                round(remaining_payback_years, 2)
                if remaining_payback_years is not None
                else None
            ),
            "historical": {
                "enabled": historical_pv_kwh > 0 or historical_savings > 0,
                "label": historical_label,
                "pv_kwh": round(historical_pv_kwh, 3),
                "savings": round(historical_savings, 2),
                "method": "manual_historical_baseline",
            },
            "combined": {
                "pv_kwh": round(combined_pv_kwh, 3),
                "savings": round(combined_savings, 2),
                "system_cost": (
                    round(float(plan.system_cost), 2)
                    if plan.system_cost is not None
                    else None
                ),
                "remaining_cost": (
                    round(remaining_cost, 2)
                    if remaining_cost is not None
                    else None
                ),
                "payback_progress_pct": (
                    round(payback_progress_pct, 1)
                    if payback_progress_pct is not None
                    else None
                ),
            },
        }

    def battery_power_average(
        self,
        minutes: int = 10,
        direction: str | None = None,
        min_power_w: float = 100.0,
    ) -> dict[str, Any]:
        minutes = max(1, min(int(minutes), 60))
        min_power_w = max(0.0, float(min_power_w))
        cutoff = (
            datetime.now(timezone.utc) - timedelta(minutes=minutes)
        ).isoformat(timespec="seconds")

        sql = (
            "SELECT AVG(battery_power_w),COUNT(*),MIN(ts_utc),MAX(ts_utc) "
            "FROM samples WHERE ts_utc>=? AND battery_power_w IS NOT NULL"
        )
        params: list[Any] = [cutoff]

        if direction == "discharging":
            sql += " AND battery_power_w>=?"
            params.append(min_power_w)
        elif direction == "charging":
            sql += " AND battery_power_w<=?"
            params.append(-min_power_w)

        row = self.conn.execute(sql, tuple(params)).fetchone()
        average = row[0] if row is not None else None
        count = int(row[1] or 0) if row is not None else 0

        return {
            "average_power_w": round(float(average), 3) if average is not None else None,
            "sample_count": count,
            "oldest_sample_utc": row[2] if row is not None else None,
            "newest_sample_utc": row[3] if row is not None else None,
            "window_minutes": minutes,
            "direction": direction,
            "min_power_w": min_power_w,
        }

    def battery_soc_trend(
        self,
        minutes: int = 30,
        min_span_minutes: float = 10.0,
        min_soc_change_pct: float = 1.0,
    ) -> dict[str, Any]:
        minutes = max(5, min(int(minutes), 180))
        min_span_minutes = max(1.0, float(min_span_minutes))
        min_soc_change_pct = max(0.1, float(min_soc_change_pct))

        cutoff = (
            datetime.now(timezone.utc) - timedelta(minutes=minutes)
        ).isoformat(timespec="seconds")

        rows = self.conn.execute(
            """
            SELECT ts_utc,battery_soc_pct
            FROM samples
            WHERE ts_utc>=? AND battery_soc_pct IS NOT NULL
            ORDER BY id
            """,
            (cutoff,),
        ).fetchall()

        result: dict[str, Any] = {
            "window_minutes": minutes,
            "sample_count": len(rows),
            "soc_pct_per_hour": None,
            "soc_change_pct": None,
            "span_minutes": None,
            "oldest_sample_utc": rows[0][0] if rows else None,
            "newest_sample_utc": rows[-1][0] if rows else None,
        }

        if len(rows) < 2:
            result["reason"] = "insufficient_soc_samples"
            return result

        oldest_ts = datetime.fromisoformat(str(rows[0][0]))
        newest_ts = datetime.fromisoformat(str(rows[-1][0]))
        span_minutes = (newest_ts - oldest_ts).total_seconds() / 60.0

        oldest_soc = float(rows[0][1])
        newest_soc = float(rows[-1][1])
        soc_change = newest_soc - oldest_soc

        result["span_minutes"] = round(span_minutes, 3)
        result["soc_change_pct"] = round(soc_change, 3)

        if span_minutes < min_span_minutes:
            result["reason"] = "insufficient_soc_time_span"
            return result

        if abs(soc_change) < min_soc_change_pct:
            result["reason"] = "insufficient_soc_change"
            return result

        rate = soc_change / (span_minutes / 60.0)
        result["soc_pct_per_hour"] = round(rate, 3)
        return result

    def history(self, hours: int = 24, points: int = 360) -> list[dict[str, Any]]:
        hours = max(1, min(int(hours), self.raw_retention_days * 24))
        points = max(10, min(int(points), 2000))
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat(timespec="seconds")
        rows = [
            dict(row)
            for row in self.conn.execute(
                """
                SELECT ts_utc,ts_local,pv_power_w,battery_soc_pct,battery_voltage_v,
                       grid_voltage_v,output_voltage_v,output_frequency_hz,operating_mode_raw,
                       temperature_f,load_power_w,battery_power_w,grid_power_w
                FROM samples WHERE ts_utc>=? ORDER BY id
                """,
                (cutoff,),
            ).fetchall()
        ]
        if len(rows) <= points:
            return rows
        stride = len(rows) / float(points)
        indexes = sorted({min(len(rows) - 1, int(i * stride)) for i in range(points)})
        return [rows[i] for i in indexes]

    def history_for_date(self, local_date: str, points: int = 1440) -> list[dict[str, Any]]:
        """Return raw telemetry for one local calendar date.

        Raw history remains limited by WALRUS_RAW_RETENTION_DAYS.
        Daily summaries may outlive the raw samples used for drill-down.
        """
        try:
            datetime.strptime(str(local_date), "%Y-%m-%d")
        except ValueError:
            return []

        points = max(10, min(int(points), 2000))
        rows = [
            dict(row)
            for row in self.conn.execute(
                """
                SELECT ts_utc,ts_local,pv_power_w,battery_soc_pct,battery_voltage_v,
                       grid_voltage_v,output_voltage_v,output_frequency_hz,operating_mode_raw,
                       temperature_f,load_power_w,battery_power_w,grid_power_w
                FROM samples
                WHERE local_date=?
                ORDER BY id
                """,
                (str(local_date),),
            ).fetchall()
        ]

        if len(rows) <= points:
            return rows

        stride = len(rows) / float(points)
        indexes = sorted(
            {min(len(rows) - 1, int(i * stride)) for i in range(points)}
        )
        return [rows[i] for i in indexes]

    def daily_csv(self, days: int = 30, poll_interval_s: float = 15.0) -> str:
        rows = self.daily(days, poll_interval_s)
        fields = [
            "date", "pv_generated_kwh", "usage_kwh", "grid_import_kwh", "grid_export_kwh",
            "battery_charge_kwh", "battery_discharge_kwh", "soc_min_pct", "soc_max_pct",
            "battery_voltage_min_v", "battery_voltage_max_v", "temperature_min_c",
            "temperature_max_c", "sample_count", "data_coverage_pct",
        ]
        output = StringIO()
        writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
        return output.getvalue()

    def raw_csv_chunks(self, days: int = 1, batch_size: int = 512):
        days = max(1, min(int(days), self.raw_retention_days))
        batch_size = max(1, min(int(batch_size), 10_000))
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat(timespec="seconds")
        export_conn = sqlite3.connect(self.path)
        export_conn.row_factory = sqlite3.Row
        try:
            cursor = export_conn.execute(
                "SELECT * FROM samples WHERE ts_utc>=? ORDER BY id", (cutoff,)
            )
            fields = [col[0] for col in (cursor.description or []) if col[0] != "id"]
            if not fields:
                yield "ts_utc\r\n"
                return
            output = StringIO()
            writer = csv.DictWriter(output, fieldnames=fields, extrasaction="ignore", lineterminator="\r\n")
            writer.writeheader()
            yield output.getvalue()
            while True:
                rows = cursor.fetchmany(batch_size)
                if not rows:
                    break
                output.seek(0)
                output.truncate(0)
                writer.writerows(dict(row) for row in rows)
                chunk = output.getvalue()
                if chunk:
                    yield chunk
        finally:
            export_conn.close()

    def raw_csv(self, days: int = 1) -> str:
        return "".join(self.raw_csv_chunks(days))

    def schema_version(self) -> int:
        return int(self.conn.execute("PRAGMA user_version").fetchone()[0])

    def diagnostics(self) -> dict[str, Any]:
        sample_count = int(self.conn.execute("SELECT COUNT(*) FROM samples").fetchone()[0])
        event_count = int(self.conn.execute("SELECT COUNT(*) FROM events").fetchone()[0])
        daily_count = int(self.conn.execute("SELECT COUNT(*) FROM daily_summary").fetchone()[0])
        size = self.path.stat().st_size if self.path.exists() else 0
        return {
            "database_path": str(self.path),
            "database_bytes": size,
            "schema_version": self.schema_version(),
            "raw_retention_days": self.raw_retention_days,
            "daily_retention_days": self.daily_retention_days,
            "sample_rows": sample_count,
            "daily_rows": daily_count,
            "event_rows": event_count,
            "timezone": self.timezone_name,
            "backup_dir": str(self.backup_dir),
            "backup_keep": self.backup_keep,
            "latest_backup": self.latest_backup(),
        }

    def purge(self) -> None:
        raw_cutoff = (datetime.now(timezone.utc) - timedelta(days=self.raw_retention_days)).isoformat(timespec="seconds")
        daily_cutoff = (datetime.now(self.tz).date() - timedelta(days=self.daily_retention_days)).isoformat()
        event_cutoff = (datetime.now(timezone.utc) - timedelta(days=self.daily_retention_days)).isoformat(timespec="seconds")
        self.conn.execute("DELETE FROM samples WHERE ts_utc < ?", (raw_cutoff,))
        self.conn.execute("DELETE FROM daily_summary WHERE local_date < ?", (daily_cutoff,))
        self.conn.execute("DELETE FROM pv_interval_energy WHERE local_date < ?", (daily_cutoff,))
        self.conn.execute("DELETE FROM events WHERE ts_utc < ?", (event_cutoff,))
        self.conn.commit()
