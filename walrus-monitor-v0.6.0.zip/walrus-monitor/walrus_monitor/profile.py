from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any


@dataclass(frozen=True)
class PollBlock:
    start: int
    count: int


@dataclass(frozen=True)
class RegisterDefinition:
    address: int
    scale: float
    unit: str
    confidence: str
    value_map: dict[int, str]


class DeviceProfile:
    """Small dependency-free profile loader.

    The bundled .yaml file intentionally uses JSON syntax, which is valid YAML 1.2.
    This keeps the image dependency-free while still allowing device profiles to be
    stored and shared as YAML documents.
    """

    def __init__(self, payload: dict[str, Any]) -> None:
        self.id = str(payload["id"])
        self.name = str(payload["name"])
        self.slave_id = int(payload.get("slave_id", 1))
        rated = payload.get("rated_output_power_w")
        self.rated_output_power_w = float(rated) if rated is not None else None
        nominal_frequency = payload.get("nominal_output_frequency_hz")
        self.nominal_output_frequency_hz = (
            float(nominal_frequency) if nominal_frequency is not None else None
        )
        self.poll_blocks = tuple(
            PollBlock(start=_to_int(item["start"]), count=int(item["count"]))
            for item in payload.get("poll_blocks", [])
        )
        self.registers = {
            name: RegisterDefinition(
                address=_to_int(spec["address"]),
                scale=float(spec.get("scale", 1.0)),
                unit=str(spec.get("unit", "")),
                confidence=str(spec.get("confidence", "unknown")),
                value_map={_to_int(k): str(v) for k, v in spec.get("value_map", {}).items()},
            )
            for name, spec in payload.get("registers", {}).items()
        }
        self.unmapped = tuple(str(x) for x in payload.get("unmapped", []))
        self.research_candidates = tuple(payload.get("research_candidates", []))

    @classmethod
    def load(cls, path: str) -> "DeviceProfile":
        payload = json.loads(Path(path).read_text())
        return cls(payload)

    def read(self, raw_registers: dict[int, int], name: str) -> float | int | None:
        spec = self.registers.get(name)
        if spec is None:
            return None
        raw = raw_registers.get(spec.address)
        if raw is None:
            return None
        value = raw * spec.scale
        if spec.scale == 1.0:
            return int(value)
        return round(float(value), 6)

    def read_raw(self, raw_registers: dict[int, int], name: str) -> int | None:
        spec = self.registers.get(name)
        if spec is None:
            return None
        return raw_registers.get(spec.address)

    def read_label(self, raw_registers: dict[int, int], name: str) -> str | None:
        spec = self.registers.get(name)
        if spec is None or not spec.value_map:
            return None
        raw = raw_registers.get(spec.address)
        if raw is None:
            return None
        return spec.value_map.get(raw, f"Unknown ({raw})")

    def as_dict(self) -> dict[str, Any]:
        registers: dict[str, Any] = {}
        for name, spec in self.registers.items():
            item: dict[str, Any] = {
                "address": f"0x{spec.address:04X}",
                "scale": spec.scale,
                "unit": spec.unit,
                "confidence": spec.confidence,
            }
            if spec.value_map:
                item["value_map"] = {str(k): v for k, v in spec.value_map.items()}
            registers[name] = item
        return {
            "id": self.id,
            "name": self.name,
            "slave_id": self.slave_id,
            "rated_output_power_w": self.rated_output_power_w,
            "nominal_output_frequency_hz": self.nominal_output_frequency_hz,
            "poll_blocks": [
                {"start": f"0x{x.start:04X}", "count": x.count} for x in self.poll_blocks
            ],
            "registers": registers,
            "unmapped": list(self.unmapped),
            "research_candidates": list(self.research_candidates),
        }


def _to_int(value: Any) -> int:
    if isinstance(value, int):
        return value
    return int(str(value), 0)
