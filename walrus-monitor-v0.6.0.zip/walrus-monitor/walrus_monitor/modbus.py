from __future__ import annotations

from dataclasses import dataclass


def crc16_modbus(data: bytes) -> int:
    """Return Modbus RTU CRC16 as an integer (wire order is little-endian)."""
    crc = 0xFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 0x0001:
                crc = (crc >> 1) ^ 0xA001
            else:
                crc >>= 1
    return crc & 0xFFFF


def append_crc(frame_without_crc: bytes) -> bytes:
    crc = crc16_modbus(frame_without_crc)
    return frame_without_crc + crc.to_bytes(2, "little")


def validate_crc(frame: bytes) -> bool:
    if len(frame) < 4:
        return False
    expected = int.from_bytes(frame[-2:], "little")
    return crc16_modbus(frame[:-2]) == expected


def build_read_holding_registers(slave: int, start: int, count: int) -> bytes:
    if not (0 <= slave <= 247):
        raise ValueError("slave must be 0..247")
    if not (0 <= start <= 0xFFFF):
        raise ValueError("start must be 0..65535")
    if not (1 <= count <= 125):
        raise ValueError("count must be 1..125")
    pdu = bytes([
        slave,
        0x03,
        (start >> 8) & 0xFF,
        start & 0xFF,
        (count >> 8) & 0xFF,
        count & 0xFF,
    ])
    return append_crc(pdu)


@dataclass(frozen=True)
class ModbusResponse:
    slave: int
    function: int
    registers: tuple[int, ...]
    raw: bytes


def parse_read_holding_response(frame: bytes) -> ModbusResponse:
    if len(frame) < 5:
        raise ValueError("frame too short")
    if not validate_crc(frame):
        raise ValueError("invalid Modbus CRC")

    slave = frame[0]
    function = frame[1]
    if function & 0x80:
        code = frame[2] if len(frame) > 2 else None
        raise ValueError(f"Modbus exception response function=0x{function:02x} code={code}")
    if function != 0x03:
        raise ValueError(f"unexpected Modbus function 0x{function:02x}")

    byte_count = frame[2]
    if byte_count % 2:
        raise ValueError("odd register byte count")
    expected_len = 3 + byte_count + 2
    if len(frame) != expected_len:
        raise ValueError(f"unexpected frame length {len(frame)}, expected {expected_len}")

    regs = []
    payload = frame[3:3 + byte_count]
    for i in range(0, len(payload), 2):
        regs.append(int.from_bytes(payload[i:i + 2], "big"))
    return ModbusResponse(slave=slave, function=function, registers=tuple(regs), raw=frame)


def expected_response_length(buffer: bytes) -> int | None:
    """Return full Modbus response frame length if enough header bytes are present."""
    if len(buffer) < 3:
        return None
    function = buffer[1]
    if function == 0x03:
        return 3 + buffer[2] + 2
    if function & 0x80:
        return 5
    return None
