from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Any


DEFAULT_VERIFICATION_NOTE = (
    "Utility rates, riders, taxes, fixed charges, seasonal periods, and tariff "
    "rules can change. Built-in plans are editable starting points only. "
    "Verify all values against your current utility tariff or bill before "
    "relying on savings or payback estimates. Walrus estimates avoided energy "
    "cost from measured solar production; it is not a utility bill calculator."
)


def _hhmm_to_minutes(value: str) -> int:
    parts = value.strip().split(":")
    if len(parts) != 2:
        raise ValueError(f"invalid time {value!r}; expected HH:MM")
    hour, minute = (int(part) for part in parts)
    if not 0 <= hour <= 23 or not 0 <= minute <= 59:
        raise ValueError(f"invalid time {value!r}; expected HH:MM")
    return hour * 60 + minute


def _parse_date(value: str | date | None) -> date | None:
    if value is None or value == "":
        return None
    if isinstance(value, date):
        return value
    return date.fromisoformat(str(value))


def _observed_date(actual: date) -> date:
    if actual.weekday() == 5:
        return actual - timedelta(days=1)
    if actual.weekday() == 6:
        return actual + timedelta(days=1)
    return actual


def _is_named_holiday(day: date, name: str) -> bool:
    if name == "us_independence_day_observed":
        return day == _observed_date(date(day.year, 7, 4))

    if name == "us_labor_day":
        first = date(day.year, 9, 1)
        first_monday = first + timedelta(days=(7 - first.weekday()) % 7)
        return day == first_monday

    raise ValueError(f"unsupported holiday identifier: {name}")


@dataclass(frozen=True)
class RatePeriod:
    name: str
    energy_rate_per_kwh: float
    start_time: str
    end_time: str
    months: tuple[int, ...] = ()
    weekdays: tuple[int, ...] = ()
    per_kwh_adjustments: dict[str, float] = field(default_factory=dict)
    excluded_holidays: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise ValueError("rate period name cannot be empty")
        if self.energy_rate_per_kwh < 0:
            raise ValueError("energy rate cannot be negative")
        _hhmm_to_minutes(self.start_time)
        _hhmm_to_minutes(self.end_time)
        if any(month < 1 or month > 12 for month in self.months):
            raise ValueError("months must be in the range 1..12")
        if any(day < 0 or day > 6 for day in self.weekdays):
            raise ValueError("weekdays must be in the range 0..6")
        if any(value < 0 for value in self.per_kwh_adjustments.values()):
            raise ValueError("per-kWh adjustments cannot be negative")

    def matches(self, local_dt: datetime) -> bool:
        if self.months and local_dt.month not in self.months:
            return False
        if self.weekdays and local_dt.weekday() not in self.weekdays:
            return False
        if any(
            _is_named_holiday(local_dt.date(), holiday)
            for holiday in self.excluded_holidays
        ):
            return False

        start = _hhmm_to_minutes(self.start_time)
        end = _hhmm_to_minutes(self.end_time)
        current = local_dt.hour * 60 + local_dt.minute

        if start == end:
            return True
        if start < end:
            return start <= current < end
        return current >= start or current < end

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "energy_rate_per_kwh": self.energy_rate_per_kwh,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "months": list(self.months),
            "weekdays": list(self.weekdays),
            "per_kwh_adjustments": dict(self.per_kwh_adjustments),
            "excluded_holidays": list(self.excluded_holidays),
        }


@dataclass(frozen=True)
class RatePlan:
    provider: str
    name: str
    default_energy_rate_per_kwh: float
    periods: tuple[RatePeriod, ...] = ()
    per_kwh_adjustments: dict[str, float] = field(default_factory=dict)
    fixed_daily_charge: float = 0.0
    savings_start_date: date | None = None
    system_cost: float | None = None
    currency: str = "USD"
    effective_date: date | None = None
    verification_note: str = DEFAULT_VERIFICATION_NOTE

    def __post_init__(self) -> None:
        if not self.provider.strip():
            raise ValueError("provider cannot be empty")
        if not self.name.strip():
            raise ValueError("plan name cannot be empty")
        if self.default_energy_rate_per_kwh < 0:
            raise ValueError("default energy rate cannot be negative")
        if any(value < 0 for value in self.per_kwh_adjustments.values()):
            raise ValueError("per-kWh adjustments cannot be negative")
        if self.fixed_daily_charge < 0:
            raise ValueError("fixed daily charge cannot be negative")
        if self.system_cost is not None and self.system_cost < 0:
            raise ValueError("system cost cannot be negative")

    def matching_period(self, local_dt: datetime) -> RatePeriod | None:
        for period in self.periods:
            if period.matches(local_dt):
                return period
        return None

    def rate_components_at(self, local_dt: datetime) -> dict[str, Any]:
        period = self.matching_period(local_dt)
        period_name = period.name if period is not None else "default"
        energy_rate = (
            float(period.energy_rate_per_kwh)
            if period is not None
            else float(self.default_energy_rate_per_kwh)
        )

        adjustments = {
            key: float(value)
            for key, value in self.per_kwh_adjustments.items()
        }
        if period is not None:
            adjustments.update(
                {
                    key: float(value)
                    for key, value in period.per_kwh_adjustments.items()
                }
            )

        return {
            "period": period_name,
            "energy_rate_per_kwh": energy_rate,
            "adjustments_per_kwh": adjustments,
            "variable_rate_per_kwh": energy_rate + sum(adjustments.values()),
        }

    def energy_rate_at(self, local_dt: datetime) -> tuple[str, float]:
        components = self.rate_components_at(local_dt)
        return components["period"], components["energy_rate_per_kwh"]

    def avoided_variable_rate_at(self, local_dt: datetime) -> tuple[str, float]:
        components = self.rate_components_at(local_dt)
        return components["period"], components["variable_rate_per_kwh"]

    def active_for(self, local_dt: datetime) -> bool:
        if self.savings_start_date is None:
            return True
        return local_dt.date() >= self.savings_start_date

    def to_dict(self) -> dict[str, Any]:
        return {
            "provider": self.provider,
            "name": self.name,
            "currency": self.currency,
            "default_energy_rate_per_kwh": self.default_energy_rate_per_kwh,
            "periods": [period.to_dict() for period in self.periods],
            "per_kwh_adjustments": dict(self.per_kwh_adjustments),
            "fixed_daily_charge": self.fixed_daily_charge,
            "savings_start_date": (
                self.savings_start_date.isoformat()
                if self.savings_start_date is not None
                else None
            ),
            "system_cost": self.system_cost,
            "effective_date": (
                self.effective_date.isoformat()
                if self.effective_date is not None
                else None
            ),
            "verification_note": self.verification_note,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RatePlan":
        periods = tuple(
            RatePeriod(
                name=str(item["name"]),
                energy_rate_per_kwh=float(item["energy_rate_per_kwh"]),
                start_time=str(item["start_time"]),
                end_time=str(item["end_time"]),
                months=tuple(int(value) for value in item.get("months", ())),
                weekdays=tuple(int(value) for value in item.get("weekdays", ())),
                per_kwh_adjustments={
                    str(key): float(value)
                    for key, value in dict(
                        item.get("per_kwh_adjustments", {})
                    ).items()
                },
                excluded_holidays=tuple(
                    str(value)
                    for value in item.get("excluded_holidays", ())
                ),
            )
            for item in data.get("periods", ())
        )
        adjustments = {
            str(key): float(value)
            for key, value in dict(data.get("per_kwh_adjustments", {})).items()
        }
        return cls(
            provider=str(data.get("provider", "Custom")),
            name=str(data.get("name", "Custom Plan")),
            default_energy_rate_per_kwh=float(
                data.get("default_energy_rate_per_kwh", 0.0)
            ),
            periods=periods,
            per_kwh_adjustments=adjustments,
            fixed_daily_charge=float(data.get("fixed_daily_charge", 0.0)),
            savings_start_date=_parse_date(data.get("savings_start_date")),
            system_cost=(
                float(data["system_cost"])
                if data.get("system_cost") not in (None, "")
                else None
            ),
            currency=str(data.get("currency", "USD")),
            effective_date=_parse_date(data.get("effective_date")),
            verification_note=str(
                data.get("verification_note", DEFAULT_VERIFICATION_NOTE)
            ),
        )


def georgia_power_overnight_advantage(
    *,
    savings_start_date: str | date | None = None,
    system_cost: float | None = None,
    super_off_peak_rate: float = 0.021859,
    off_peak_rate: float = 0.101676,
    on_peak_rate: float = 0.297868,
    off_peak_fuel_rate: float = 0.037441,
    on_peak_fuel_rate: float = 0.052269,
    fixed_daily_charge: float = 0.4603,
) -> RatePlan:
    return RatePlan(
        provider="Georgia Power",
        name="Overnight Advantage",
        default_energy_rate_per_kwh=off_peak_rate,
        periods=(
            RatePeriod(
                name="super_off_peak",
                energy_rate_per_kwh=super_off_peak_rate,
                start_time="23:00",
                end_time="07:00",
            ),
            RatePeriod(
                name="on_peak",
                energy_rate_per_kwh=on_peak_rate,
                start_time="14:00",
                end_time="19:00",
                months=(6, 7, 8, 9),
                weekdays=(0, 1, 2, 3, 4),
                per_kwh_adjustments={"fuel": on_peak_fuel_rate},
                excluded_holidays=(
                    "us_independence_day_observed",
                    "us_labor_day",
                ),
            ),
        ),
        per_kwh_adjustments={"fuel": off_peak_fuel_rate},
        fixed_daily_charge=fixed_daily_charge,
        savings_start_date=_parse_date(savings_start_date),
        system_cost=system_cost,
        effective_date=date(2026, 6, 1),
    )
